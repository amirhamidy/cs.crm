"use client";

import { useCallback, useEffect, useState } from "react";
import CompanyNews from "@/components/user/dashboard/CompanyNews";
import ScoreCard from "@/components/user/dashboard/ScoreCard";
import TodayEventCards from "@/components/user/dashboard/TodayEventCards";
import axiosInstance from "@/lib/axiosInstance";
import { useAuthStore } from "@/store/authStore";
import EmployeePerformanceChart from "@/components/user/dashboard/EmployeePerformanceChart";
import DepartmentScoreManager from "@/components/user/dashboard/DepartmentScoreManager";

interface CalendarEvent {
    id: number;
    title: string;
    start: string;
    end: string;
    type: "task" | "internal_task" | "note";
}

interface CalendarResponse {
    start: string;
    end: string;
    events: CalendarEvent[];
}

function getLocalISODate(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

export default function EmployeeDashboardPage() {
    const employeeId = useAuthStore((state) => state.userId);
    const [events, setEvents] = useState<CalendarEvent[]>([]);

    const fetchCalendarEvents = useCallback(async () => {
        try {
            const today = new Date();

            const yesterday = new Date(today);
            yesterday.setDate(today.getDate() - 1);

            const tomorrow = new Date(today);
            tomorrow.setDate(today.getDate() + 1);

            const start = getLocalISODate(yesterday);
            const end = getLocalISODate(tomorrow);

            const response = await axiosInstance.get<CalendarResponse>(
                "/appraisal/api/v1/calendar/",
                {
                    params: {
                        start,
                        end,
                    },
                }
            );

            const calendarEvents = Array.isArray(response.data?.events)
                ? response.data.events
                : [];

            setEvents(calendarEvents);
        } catch (error) {
            console.error("Calendar API Error:", error);
            setEvents([]);
        }
    }, []);

    useEffect(() => {
        fetchCalendarEvents();
    }, [fetchCalendarEvents]);

    return (
        <div
            className="min-h-screen w-full"
            dir="rtl"
        >
            <div className="w-full space-y-6">
                <div className="grid w-full grid-cols-1 gap-6 lg:grid-cols-3">
                    <div className="space-y-6 lg:col-span-2">
                        <div>
                            <EmployeePerformanceChart />
                        </div>

                        <div className="flex justify-center gap-2">
                            <span className="text-blue-500">
                                _________
                            </span>

                            <span className="text-[14px]">
                                امروز شما
                            </span>

                            <span className="text-blue-500">
                                _________
                            </span>
                        </div>

                        <TodayEventCards events={events} />
                    </div>

                    <div className="space-y-6">
                        <CompanyNews
                            onNoteCreated={fetchCalendarEvents}
                        />

                        {employeeId !== null && <ScoreCard />}
                    </div>
                </div>
                <DepartmentScoreManager />
            </div>
        </div>
    );
}