"use client";

import { useEffect, useMemo, useState } from "react";
import { WAREHOUSE_ENDPOINTS, fetchAll } from "@/lib/warehouseApi";
import { useCurrentEmployee } from "@/hooks/usecurrentemployee";
import { useAuthStore } from "@/store/authStore";
import type { ApiWarehouseStaff } from "@/types/warehouse";
import { findEmployeeStaff, getEmployeeId } from "@/utils/warehouseEmployee";


export default function useWarehouseAccess() {
  const { employee, loading: employeeLoading } = useCurrentEmployee();
  const userType = useAuthStore((state) => state.userType);
  const hasHydrated = useAuthStore((state) => state.hasHydrated);

  const [staff, setStaff] = useState<ApiWarehouseStaff[]>([]);
  const [staffLoading, setStaffLoading] = useState(true);

  const isAdmin = Number(userType) === 1;
  const employeeId = useMemo(() => getEmployeeId(employee), [employee]);

  useEffect(() => {
    if (!hasHydrated || employeeLoading) return;

    let alive = true;
    setStaffLoading(true);

    
    
    fetchAll<ApiWarehouseStaff>(WAREHOUSE_ENDPOINTS.staff)
      .then((list) => {
        if (alive) setStaff(list);
      })
      .catch(() => {
        if (alive) setStaff([]);
      })
      .finally(() => {
        if (alive) setStaffLoading(false);
      });

    return () => {
      alive = false;
    };
  }, [hasHydrated, employeeLoading]);

  const myStaff = useMemo(
    () => findEmployeeStaff(staff, employeeId),
    [staff, employeeId],
  );

  const isWarehouseStaff = myStaff?.is_active === true;

  const assignedWarehouseIds = useMemo(
    () =>
      myStaff && Array.isArray(myStaff.warehouses)
        ? myStaff.warehouses.map(Number)
        : [],
    [myStaff],
  );

  return {
    ready: hasHydrated && !employeeLoading && !staffLoading,
    employeeId,
    myStaff,
    assignedWarehouseIds,
    isAdmin,
    isWarehouseStaff,
    hasFullAccess: isAdmin || isWarehouseStaff,
    limitedAccess: isAdmin || Boolean(employeeId),
  };
}
