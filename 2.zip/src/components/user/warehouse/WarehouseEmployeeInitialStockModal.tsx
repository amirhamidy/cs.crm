"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, m, useReducedMotion } from "framer-motion";
import { Backdrop } from "@/components/ui/Backdrop";
import { panelMotion } from "@/lib/motion";
import { Boxes, X } from "lucide-react";
import { useTheme } from "next-themes";
import type { AxiosError } from "axios";
import { NiceSelect } from "@/components/ui/NiceSelect";
import axiosInstance from "@/lib/axiosInstance";
import type { ApiProduct, ApiStockInfo, ApiWarehouseStaff } from "@/types/warehouse";

import { BusyContent } from "@/components/ui/Button";
interface WarehouseEmployeeInitialStockModalProps {
    isOpen: boolean;
    onClose: () => void;
    product: ApiProduct;
    staff: ApiWarehouseStaff[];
    performedById?: number | null;
    warehouseId?: number | null;
    onCompleted: (stockInfo: ApiStockInfo) => void;
}

function getErrorMessage(err: unknown, fallback: string) {
    const error = err as AxiosError<Record<string, unknown>>;
    const data = error.response?.data;

    if (!data) {
        return fallback;
    }

    for (const key of [
        "detail",
        "quantity",
        "minimum_stock",
        "maximum_stock",
        "performed_by_id",
        "message",
        "error",
        "non_field_errors",
    ]) {
        const value = data[key];

        if (typeof value === "string") {
            return value;
        }

        if (
            Array.isArray(value) &&
            typeof value[0] === "string"
        ) {
            return value[0];
        }
    }

    return fallback;
}

export default function WarehouseEmployeeInitialStockModal({
    isOpen,
    onClose,
    product,
    staff,
    performedById,
    warehouseId,
    onCompleted,
}: WarehouseEmployeeInitialStockModalProps) {
    const reduced = useReducedMotion() ?? false;
    const { resolvedTheme } = useTheme();
    const isDark = resolvedTheme === "dark";

    const [selectedStaff, setSelectedStaff] = useState("");
    const [quantity, setQuantity] = useState("");
    const [minimumStock, setMinimumStock] = useState("");
    const [maximumStock, setMaximumStock] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    useEffect(() => {
        if (!isOpen) {
            return;
        }

        setSelectedStaff(
            performedById != null
                ? String(performedById)
                : staff.length === 1
                    ? String(staff[0].id)
                    : "",
        );

        setQuantity("");
        setMinimumStock("");
        setMaximumStock("");
        setError("");
    }, [isOpen, performedById, staff]);

    function handleClose() {
        if (!loading) {
            onClose();
        }
    }

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();

        if (
            !selectedStaff ||
            !quantity ||
            !minimumStock ||
            !maximumStock
        ) {
            setError("تمام فیلدها الزامی است");
            return;
        }

        const qty = Number(quantity);
        const min = Number(minimumStock);
        const max = Number(maximumStock);

        if (
            !Number.isFinite(qty) ||
            !Number.isFinite(min) ||
            !Number.isFinite(max)
        ) {
            setError("مقادیر وارد شده معتبر نیستند");
            return;
        }

        if (qty < 0 || min < 0 || max < 0) {
            setError("مقادیر نمی‌توانند منفی باشند");
            return;
        }

        if (min > max) {
            setError(
                "حداقل موجودی نمی‌تواند بیشتر از حداکثر موجودی باشد",
            );
            return;
        }

        if (qty > max) {
            setError(
                "موجودی فعلی نمی‌تواند بیشتر از حداکثر موجودی باشد",
            );
            return;
        }

        if (warehouseId == null) {
            setError("انبار مشخص نشده است");
            return;
        }

        setLoading(true);
        setError("");

        try {
            const { data } = await axiosInstance.post<ApiStockInfo>(
                "/warehouse/api/v1/process/stock/initial/",
                {
                    warehouse_id: Number(warehouseId),
                    product_id: product.id,
                    performed_by_id: Number(selectedStaff),
                    quantity: qty,
                    minimum_stock: min,
                    maximum_stock: max,
                },
            );

            onCompleted(data);
            onClose();
        } catch (err) {
            setError(
                getErrorMessage(
                    err,
                    "خطا در ثبت موجودی اولیه",
                ),
            );
        } finally {
            setLoading(false);
        }
    }

    const bg = isDark ? "#111827" : "#ffffff";
    const border = isDark
        ? "rgba(255,255,255,.06)"
        : "rgba(15,23,42,.06)";
    const text = isDark ? "#f3f4f6" : "#1f2937";
    const muted = isDark ? "#9ca3af" : "#6b7280";
    const inputBg = isDark
        ? "rgba(255,255,255,.035)"
        : "rgba(15,23,42,.025)";

    return (
        <AnimatePresence>
            {isOpen && (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center px-4"
                >
                    <Backdrop onClick={handleClose} />
                    <m.div
                        {...panelMotion(false, reduced)}
                        dir="rtl"
                        className="relative w-full max-w-sm overflow-hidden rounded-[2rem] border"
                        style={{
                            background: bg,
                            borderColor: border,
                        }}
                    >
                        <div className="flex items-center justify-between px-8 pb-6 pt-8">
                            <div className="flex min-w-0 items-center gap-2.5">
                                <div
                                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl"
                                    style={{
                                        background: isDark
                                            ? "rgba(99,102,241,.12)"
                                            : "rgba(99,102,241,.08)",
                                    }}
                                >
                                    <Boxes
                                        size={15}
                                        className="text-indigo-500"
                                    />
                                </div>

                                <div className="min-w-0">
                                    <h3
                                        className="text-[14px] font-extrabold"
                                        style={{ color: text }}
                                    >
                                        ثبت موجودی اولیه
                                    </h3>

                                    <p
                                        className="mt-0.5 truncate text-[12px]"
                                        style={{ color: muted }}
                                    >
                                        {product.name}
                                    </p>
                                </div>
                            </div>

                            <button
                                type="button"
                                onClick={handleClose}
                                disabled={loading}
                                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl disabled:opacity-40"
                                style={{
                                    background: isDark
                                        ? "rgba(255,255,255,.05)"
                                        : "rgba(15,23,42,.05)",
                                    color: muted,
                                }}
                            >
                                <X size={15} />
                            </button>
                        </div>

                        <form
                            onSubmit={handleSubmit}
                            autoComplete="off"
                            className="flex flex-col gap-4 px-8 pb-8"
                        >
                            <NiceSelect
                                label="ثبت‌کننده"
                                placeholder="انتخاب ثبت‌کننده"
                                disabled={loading || Boolean(performedById)}
                                options={staff.map((item) => ({
                                    id: Number(item.id),
                                    label: item.full_name,
                                }))}
                                value={selectedStaff === "" ? null : Number(selectedStaff)}
                                onChange={(id) => {
                                    setSelectedStaff(String(id));
                                    setError("");
                                }}
                            />

                            <div className="relative">
                                <input
                                    id="employee_initial_stock_quantity"
                                    type="number"
                                    min="0"
                                    step="any"
                                    value={quantity}
                                    onChange={(e) => {
                                        setQuantity(
                                            e.target.value,
                                        );
                                        setError("");
                                    }}
                                    placeholder="موجودی فعلی"
                                    disabled={loading}
                                    dir="ltr"
                                    className="h-12 w-full rounded-2xl border px-4 text-[13px] font-medium outline-none transition placeholder:text-gray-400 disabled:opacity-60"
                                    style={{
                                        background: inputBg,
                                        borderColor: border,
                                        color: text,
                                    }}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <input
                                    id="employee_initial_stock_min"
                                    type="number"
                                    min="0"
                                    step="any"
                                    value={minimumStock}
                                    onChange={(e) => {
                                        setMinimumStock(
                                            e.target.value,
                                        );
                                        setError("");
                                    }}
                                    placeholder="حداقل موجودی"
                                    disabled={loading}
                                    dir="ltr"
                                    className="h-12 w-full rounded-2xl border px-4 text-[13px] font-medium outline-none placeholder:text-gray-400 disabled:opacity-60"
                                    style={{
                                        background: inputBg,
                                        borderColor: border,
                                        color: text,
                                    }}
                                />

                                <input
                                    id="employee_initial_stock_max"
                                    type="number"
                                    min="0"
                                    step="any"
                                    value={maximumStock}
                                    onChange={(e) => {
                                        setMaximumStock(
                                            e.target.value,
                                        );
                                        setError("");
                                    }}
                                    placeholder="حداکثر موجودی"
                                    disabled={loading}
                                    dir="ltr"
                                    className="h-12 w-full rounded-2xl border px-4 text-[13px] font-medium outline-none placeholder:text-gray-400 disabled:opacity-60"
                                    style={{
                                        background: inputBg,
                                        borderColor: border,
                                        color: text,
                                    }}
                                />
                            </div>

                            {error && (
                                <p className="-mt-1 text-center text-[12px] font-semibold text-red-500">
                                    {error}
                                </p>
                            )}

                            <m.button
                                type="submit"
                                disabled={loading}
                                whileTap={{ scale: 0.97 }}
                                className="relative flex items-center justify-center rounded-full py-3 text-[13px] font-bold text-white disabled:opacity-50"
                                style={{
                                    background:
                                        "linear-gradient(135deg,#6366f1,#8b5cf6)",
                                }}
                            >
                                <BusyContent busy={loading}>
                                    ثبت موجودی اولیه
                                </BusyContent>
                            </m.button>
                        </form>
                    </m.div>
                </div>
            )}
        </AnimatePresence>
    );
}