"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  XAxis,
  YAxis,
} from "recharts";
import { ChartContainer, type ChartConfig } from "@/components/ui/chart";

type TimeRange = "weekly" | "monthly" | "yearly";

type ChartPoint = {
  name: string;
  sales: number;
};

type SalesChartData = Record<TimeRange, ChartPoint[]>;

const chartConfig: ChartConfig = {
  sales: { label: "فروش", color: "#38bdf8" },
};

const ranges: { key: TimeRange; label: string; sub: string }[] = [
  { key: "weekly", label: "هفتگی", sub: "هفته" },
  { key: "monthly", label: "ماهانه", sub: "ماه" },
  { key: "yearly", label: "سالانه", sub: "سال" },
];

const CHART_DEFS = (
  <defs>
    <linearGradient id="salesGradFill" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.3} />
      <stop offset="100%" stopColor="#38bdf8" stopOpacity={0} />
    </linearGradient>
  </defs>
);

type ActivePoint = {
  name: string;
  sales: number;
};

export default function SalesChart({ data: chartData }: { data: SalesChartData }) {
  const [activeRange, setActiveRange] = useState<TimeRange>("monthly");
  const [activePoint, setActivePoint] = useState<ActivePoint | null>(null);

  const data = useMemo(
    () => chartData[activeRange] ?? [],
    [chartData, activeRange]
  );

  const currentRange = useMemo(
    () => ranges.find((r) => r.key === activeRange),
    [activeRange]
  );

  const hasData = useMemo(
    () => data.some((item) => item.sales > 0),
    [data],
  );

  const handleMouseMove = useCallback(
    (state: any) => {
      if (
        !state ||
        !state.isTooltipActive ||
        state.activeTooltipIndex === undefined ||
        state.activeTooltipIndex === null
      ) {
        return;
      }

      const index = Number(state.activeTooltipIndex);
      const item = data[index];

      if (!item) return;

      setActivePoint((current) => {
        if (
          current &&
          current.name === item.name &&
          current.sales === item.sales
        ) {
          return current;
        }

        return {
          name: item.name,
          sales: item.sales,
        };
      });
    },
    [data]
  );

  const handleMouseLeave = useCallback(() => {
    setActivePoint(null);
  }, []);

  useEffect(() => {
    setActivePoint(null);
  }, [activeRange]);

  const formattedSales = useMemo(
    () =>
      activePoint
        ? activePoint.sales.toLocaleString("fa-IR")
        : null,
    [activePoint]
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.3,
        ease: [0.25, 0.46, 0.45, 0.94],
      }}
      className="relative overflow-hidden rounded-2xl border border-gray-100 bg-white p-4 shadow-sm dark:border-white/5 dark:bg-slate-950"
    >
      <div className="mb-3 flex items-center justify-between" dir="rtl">
        <div>
          <h3 className="text-[14px] font-semibold text-gray-900 dark:text-white">
            نمودار فروش
          </h3>

          <p className="mt-0.5 text-[13px] text-gray-500 dark:text-gray-400">
            گزارش عملکرد {currentRange?.sub}
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-xl border border-gray-100 bg-gray-50/80 p-1 dark:border-white/5 dark:bg-slate-900/50">
          {ranges.map((range) => (
            <button
              key={range.key}
              type="button"
              onClick={() => setActiveRange(range.key)}
              className="relative rounded-lg px-2.5 py-1 text-[11px] font-medium"
            >
              {activeRange === range.key && (
                <motion.span
                  layoutId="salesChartRangeIndicator"
                  className="absolute inset-0 rounded-lg bg-white shadow-sm dark:bg-slate-800"
                  transition={{
                    type: "spring",
                    stiffness: 400,
                    damping: 30,
                  }}
                />
              )}

              <span
                className={`relative z-10 transition-colors ${activeRange === range.key
                  ? "text-gray-900 dark:text-white"
                  : "text-gray-500 dark:text-gray-400"
                  }`}
              >
                {range.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="relative h-[180px]">
        <div className="absolute left-2 top-2 z-10 min-w-[150px]">
          <AnimatePresence mode="wait">
            {activePoint && (
              <motion.div
                key={`${activeRange}-${activePoint.name}`}
                initial={{
                  opacity: 0,
                  y: 4,
                  scale: 0.96,
                }}
                animate={{
                  opacity: 1,
                  y: 0,
                  scale: 1,
                }}
                exit={{
                  opacity: 0,
                  y: 4,
                  scale: 0.96,
                }}
                transition={{ duration: 0.15 }}
                className="pointer-events-none rounded-xl border border-gray-200/60 bg-white/95 px-3 py-2 shadow-lg backdrop-blur-sm dark:border-white/10 dark:bg-slate-900/95"
                style={{
                  boxShadow:
                    "0 4px 20px rgba(56,189,248,0.35)",
                }}
              >
                <div className="mb-1 flex items-center gap-1.5">
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{
                      backgroundColor: "#38bdf8",
                    }}
                  />

                  <span className="text-[12px] font-semibold text-gray-800 dark:text-gray-100">
                    {activePoint.name}
                  </span>
                </div>

                <div className="flex flex-col gap-0.5">
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">
                    فروش:{" "}
                    <span
                      className="font-bold tabular-nums"
                      style={{
                        color: "#38bdf8",
                      }}
                    >
                      {formattedSales}
                    </span>
                  </p>

                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <ChartContainer
          config={chartConfig}
          className="h-full w-full"
        >
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={data}
              margin={{
                top: 4,
                right: 4,
                left: -24,
                bottom: 0,
              }}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
            >
              {CHART_DEFS}

              <CartesianGrid
                strokeDasharray="3 3"
                className="[&_line]:stroke-gray-100 dark:[&_line]:stroke-white/[0.04]"
                vertical={false}
              />

              <XAxis
                dataKey="name"
                tick={{
                  fontSize: 11,
                  fontWeight: 500,
                }}
                className="[&_text]:fill-gray-500 dark:[&_text]:fill-gray-400"
                axisLine={false}
                tickLine={false}
                dy={5}
              />

              <YAxis
                tick={{
                  fontSize: 11,
                  fontWeight: 500,
                }}
                className="[&_text]:fill-gray-500 dark:[&_text]:fill-gray-400"
                axisLine={false}
                tickLine={false}
                tickFormatter={(v: number) => `${v}`}
              />

              <Area
                type="monotone"
                dataKey="sales"
                stroke="#38bdf8"
                strokeWidth={2.5}
                fill="url(#salesGradFill)"
                dot={false}
                activeDot={{
                  r: 5,
                  strokeWidth: 0,
                  fill: "#38bdf8",
                }}
                isAnimationActive={false}
              />

            </AreaChart>
          </ResponsiveContainer>
        </ChartContainer>

        {!hasData && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div
              className="text-xs text-gray-400 dark:text-gray-500"
              dir="rtl"
            >
              تسک فروخته شده‌ای در این بازه ثبت نشده است.
            </div>
          </div>
        )}
      </div>

      {hasData && (
        <div
          className="mt-2 flex items-center justify-end gap-4"
          dir="rtl"
        >
          {Object.entries(chartConfig).map(([key, val]) => (
            <div
              key={key}
              className="flex items-center gap-1.5"
            >
              <span
                className="inline-block h-0.5 w-3 rounded-full"
                style={{
                  backgroundColor: val.color,
                }}
              />

              <span className="text-[11px] text-gray-500 dark:text-gray-400">
                {val.label}
              </span>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}