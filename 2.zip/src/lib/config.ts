declare global {
  interface Window {
    __APP_CONFIG__?: { API_URL?: string };
  }
}

export const DEFAULT_API_URL = "https://api.radco4000.ir";

export function getApiUrl(): string {
  const fromWindow =
    typeof window !== "undefined" ? window.__APP_CONFIG__?.API_URL : undefined;

  const value = (
    fromWindow ||
    process.env.NEXT_PUBLIC_API_URL ||
    DEFAULT_API_URL
  ).trim();

  return value.replace(/\/+$/, "");
}
