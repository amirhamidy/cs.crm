import { ListSkeleton } from "@/components/ui/skeletons";

export default function Loading() {
    return <ListSkeleton rows={4} />;
}
