"use client";

import SearchField from "@/components/ui/SearchField";
import { useMemo, useState } from "react";
import { CountSkeleton, TaskCardSkeleton } from "@/components/ui/skeletons";
import { AnimatePresence, m } from "framer-motion";
import { Search, X, Archive, ArrowRight, Ban, CheckCircle2, ClipboardList, Layers3, RefreshCw, ShoppingBag } from "lucide-react";
import { Spinner as Loader2 } from "@/components/ui/Spinner";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { tasksApi } from "@/lib/api";
import { usePaginatedList } from "@/hooks/usePaginatedList";
import Pagination from "@/components/ui/Pagination";
import { Task } from "@/types/task";
import TaskCard from "@/components/tasks/TaskCard";

type ArchiveFilter = "all" | "completed" | "sold" | "cancelled";

const archiveFilters: { id: ArchiveFilter; label: string; icon: typeof Layers3; color: string }[] = [
    { id: "all", label: "همه", icon: Layers3, color: "#818cf8" },
    { id: "completed", label: "تکمیل شده", icon: CheckCircle2, color: "#34d399" },
    { id: "sold", label: "فروش رفته", icon: ShoppingBag, color: "#fbbf24" },
    { id: "cancelled", label: "لغو شده", icon: Ban, color: "#fb7185" },
];

export default function AdminArchivedTasksPage() {
    const router = useRouter();
    const { resolvedTheme } = useTheme();
    const isDark = resolvedTheme === "dark";

    const [filter, setFilter] = useState<ArchiveFilter>("all");
    const list = usePaginatedList<Task>((params, signal) => tasksApi.archivePage<Task>(params, signal), { pageSize: 12 });
    const loading = list.loading;
    const tasks = list.data;
    const fetchAll = list.refetch;

    const filteredTasks = useMemo(() => (filter === "all" ? tasks : tasks.filter((task) => task.status === filter)), [tasks, filter]);

    const getCount = (id: ArchiveFilter) => (id === "all" ? list.count : tasks.filter((task) => task.status === id).length);

    return (
        <div className="flex flex-col gap-5 p-3 sm:p-4 md:p-6" dir="rtl">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl" style={{ background: isDark ? "rgba(99,102,241,0.14)" : "rgba(99,102,241,0.08)" }}>
                        <Archive size={18} className="text-indigo-500" />
                    </div>

                    <div className="min-w-0">
                        <h1 className="text-[15px] font-extrabold text-gray-900 dark:text-white">بایگانی تسک‌ها</h1>
                        <p className="mt-0.5 text-[11.5px] text-gray-500 dark:text-gray-400">{loading ? <CountSkeleton /> : `${list.count} تسک`}</p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
<SearchField value={list.search} onChange={list.setSearch} placeholder="جستجوی بایگانی وظایف..." />
                    <button
                        type="button"
                        onClick={() => router.push("/admin/tasks")}
                        className="flex h-10 items-center gap-2 rounded-2xl px-3.5 text-[12px] font-bold transition-colors"
                        style={{ background: isDark ? "rgba(255,255,255,0.05)" : "rgba(15,23,42,0.05)", color: isDark ? "#d1d5db" : "#4b5563" }}
                    >
                        <ArrowRight size={15} />
                        بازگشت به وظایف
                    </button>

                    <button
                        type="button"
                        onClick={fetchAll}
                        disabled={loading}
                        className={`flex h-10 w-10 items-center justify-center rounded-2xl transition-colors disabled:opacity-50 `}
                        style={{ background: isDark ? "rgba(255,255,255,0.05)" : "rgba(15,23,42,0.05)", color: isDark ? "#d1d5db" : "#4b5563" }}
                        title="بارگذاری مجدد"
                    >
                        {loading ? <Loader2 size={15} /> : <RefreshCw size={15} />}
                    </button>
                </div>
            </div>


            <div className="flex flex-wrap items-center gap-2">
                {archiveFilters.map(({ id, label, icon: Icon, color }) => {
                    const isActive = filter === id;
                    const count = getCount(id);

                    return (
                        <button
                            key={id}
                            type="button"
                            onClick={() => setFilter(id)}
                            className="flex items-center gap-2 rounded-2xl border px-3.5 py-2 text-[11.5px] font-bold transition-all duration-200"
                            style={{
                                color: isActive ? color : undefined,
                                backgroundColor: isActive ? `${color}18` : isDark ? "rgba(255,255,255,0.03)" : "rgba(15,23,42,0.03)",
                                borderColor: isActive ? `${color}45` : isDark ? "rgba(255,255,255,0.07)" : "rgba(15,23,42,0.07)",
                            }}
                        >
                            <Icon size={13} style={{ color: isActive ? color : "rgb(148 163 184)" }} />
                            <span className={isActive ? "" : "text-gray-500 dark:text-gray-400"}>{label}</span>
                            <span className="rounded-full px-1.5 py-0.5 text-[9.5px] font-extrabold tabular-nums" style={{ color, backgroundColor: `${color}18` }}>
                                {count}
                            </span>
                        </button>
                    );
                })}
            </div>

            {loading && <TaskCardSkeleton />}

            {!loading && !list.error && filteredTasks.length === 0 && (
                <div className="flex flex-col items-center justify-center gap-2 py-16">
                    <ClipboardList size={28} className="text-gray-300 dark:text-gray-700" />
                    <p className="text-[12.5px] text-gray-500 dark:text-gray-400">تسکی در این وضعیت یافت نشد</p>
                </div>
            )}

            {!loading && filteredTasks.length > 0 && (
                <m.div layout className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
                    <AnimatePresence mode="popLayout">
                        {filteredTasks.map((task, index) => (
                            <m.div key={task.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                                <TaskCard task={task} index={index} readOnly />
                            </m.div>
                        ))}
                    </AnimatePresence>
                </m.div>
            )}

            {list.totalPages > 1 && <Pagination page={list.page} totalPages={list.totalPages} onChange={list.setPage} />}
        </div>
    );
}
