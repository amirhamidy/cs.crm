"use client";

import { memo, useEffect, useMemo, useState } from "react";
import { m } from "framer-motion";
import { ExternalLink, FilePlus, FileText, GitBranch, Pencil, Trash2, Users, X } from "lucide-react";
import { SkeletonText } from "@/components/ui/Skeleton";
import { Department, HumanResource, HumanResourceFile, deleteDocumentFile, getDocumentFiles } from "./humanResourceApi";
import { extractError, gradientOf, initialOf } from "./hrUtils";

interface Props {
    document: HumanResource;
    departments: Department[];
    canManage: boolean;
    onEdit: () => void;
    onDelete: () => void;
    onSteps: () => void;
    onAddFile: () => void;
    onChange: () => void;
}

const iconBtn = "flex h-7 w-7 items-center justify-center rounded-lg text-gray-400 transition";

function HumanResourceCard({ document, departments, canManage, onEdit, onDelete, onSteps, onAddFile, onChange }: Props) {
    const dep = departments.find((d) => d.name === document.title);

    
    
    const embedded = document.filesEmbedded !== false;
    const [fetched, setFetched] = useState<HumanResourceFile[] | null>(null);
    const [fetching, setFetching] = useState(false);
    const [removedIds, setRemovedIds] = useState<number[]>([]);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (embedded) {
            setFetched(null);
            return;
        }
        let alive = true;
        setFetching(true);
        getDocumentFiles(document.id)
            .then(({ data }) => {
                if (alive) setFetched(data);
            })
            .catch(() => {
                if (alive) setFetched([]);
            })
            .finally(() => {
                if (alive) setFetching(false);
            });
        return () => {
            alive = false;
        };
    }, [embedded, document]);

    
    const files = useMemo(
        () =>
            (embedded ? document.files : fetched ?? [])
                .filter((f) => f.step == null)
                .filter((f) => !removedIds.includes(f.id)),
        [embedded, document.files, fetched, removedIds],
    );

    const removeFile = async (id: number) => {
        if (!confirm("آیا از حذف فایل مطمئن هستید؟")) return;
        try {
            setError(null);
            await deleteDocumentFile(id);
            setRemovedIds((prev) => [...prev, id]);
            onChange();
        } catch (e) {
            setError(extractError(e, "حذف فایل انجام نشد."));
        }
    };

    return (
        <m.div
            layout
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97 }}
            whileHover={{ y: -3 }}
            transition={{ type: "spring", damping: 24, stiffness: 260 }}
            className="group overflow-hidden rounded-[1.45rem] border border-gray-100 bg-white shadow-sm transition-shadow hover:shadow-xl hover:shadow-black/[0.04] dark:border-white/[0.06] dark:bg-[#111827] dark:hover:shadow-black/20"
            dir="rtl"
        >
            <div className="p-3">
                <div className="flex items-start gap-3">
                    <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${gradientOf(document.id)} text-[14px] font-extrabold text-white shadow-sm`}>
                        {initialOf(document.title, "م")}
                    </div>

                    <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                                <h3 className="truncate text-[13px] font-extrabold text-gray-900 dark:text-white">{document.title}</h3>
                                <div className="mt-1.5 flex items-center gap-1.5">
                                    <span className="flex h-5 w-5 items-center justify-center rounded-md bg-gray-100 dark:bg-white/[0.06]">
                                        <Users size={10} className="text-gray-400" />
                                    </span>
                                    <span className="truncate text-[10.5px] font-semibold text-gray-400">
                                        {dep ? `دپارتمان ${dep.name}` : "قابل مشاهده برای همه"}
                                    </span>
                                </div>
                            </div>

                            {canManage && (
                                <div className="flex shrink-0 items-center gap-1">
                                    <button type="button" onClick={onAddFile} title="افزودن فایل" aria-label="افزودن فایل" className={`${iconBtn} hover:bg-indigo-50 hover:text-indigo-500 dark:hover:bg-indigo-500/10`}>
                                        <FilePlus size={13} />
                                    </button>
                                    <button type="button" onClick={onEdit} className={`${iconBtn} hover:bg-blue-50 hover:text-blue-500 dark:hover:bg-blue-500/10`}>
                                        <Pencil size={13} />
                                    </button>
                                    <button type="button" onClick={onDelete} className={`${iconBtn} hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10`}>
                                        <Trash2 size={13} />
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="mt-3 h-px bg-gray-100 dark:bg-white/[0.06]" />

                <div className="mt-3">
                    {fetching && files.length === 0 ? (
                        <SkeletonText lines={2} />
                    ) : files.length > 0 ? (
                        <div className="space-y-1.5">
                            {files.map((f) => (
                                <m.div
                                    key={f.id}
                                    initial={{ opacity: 0, y: 4 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="flex items-center gap-2 rounded-xl bg-gray-50 px-2.5 py-2 dark:bg-white/[0.035]"
                                >
                                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white shadow-sm dark:bg-white/[0.06]">
                                        <FileText size={12} className="text-indigo-500" />
                                    </span>

                                    {f.file ? (
                                        <a href={f.file} target="_blank" rel="noreferrer" className="min-w-0 flex-1 truncate text-[11px] font-bold text-gray-600 transition hover:text-indigo-500 dark:text-gray-300">
                                            {f.title?.trim() || "مشاهده فایل"}
                                        </a>
                                    ) : (
                                        <span className="min-w-0 flex-1 truncate text-[11px] font-bold text-gray-400">
                                            {f.title?.trim() || "فایل بدون لینک"}
                                        </span>
                                    )}

                                    {f.file && (
                                        <a
                                            href={f.file}
                                            target="_blank"
                                            rel="noreferrer"
                                            aria-label="بازکردن فایل"
                                            className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-gray-300 transition hover:bg-indigo-50 hover:text-indigo-500 dark:hover:bg-indigo-500/10"
                                        >
                                            <ExternalLink size={11} />
                                        </a>
                                    )}

                                    {canManage && (
                                        <button type="button" onClick={() => removeFile(f.id)} className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg text-gray-400 transition hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10">
                                            <X size={11} />
                                        </button>
                                    )}
                                </m.div>
                            ))}
                        </div>
                    ) : (
                        <div className="flex items-center gap-2 rounded-xl border border-dashed border-gray-200 px-2.5 py-2 dark:border-white/[0.07]">
                            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gray-50 dark:bg-white/[0.04]">
                                <FileText size={12} className="text-gray-300" />
                            </span>
                            <span className="text-[10.5px] font-semibold text-gray-400">فایلی برای این منبع ثبت نشده</span>
                        </div>
                    )}

                    {error && <p className="mt-1.5 text-[10.5px] font-semibold text-rose-500">{error}</p>}
                </div>

                <m.button
                    type="button"
                    whileTap={{ scale: 0.98 }}
                    onClick={onSteps}
                    className="mt-3 flex h-9 w-full items-center justify-center gap-2 rounded-full bg-indigo-600 text-[11.5px] font-extrabold text-white transition hover:bg-indigo-500"
                >
                    <GitBranch size={13} />
                    مشاهده مراحل
                </m.button>
            </div>
        </m.div>
    );
}

export default memo(HumanResourceCard);