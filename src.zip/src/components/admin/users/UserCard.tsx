"use client";

import {
    memo,
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react";
import dynamic from "next/dynamic";
import { AnimatePresence } from "framer-motion";
import {
    CalendarDays,
    MoreVertical,
    Phone,
    ShieldCheck,
    Star,
} from "lucide-react";
import { accountsApi } from "@/lib/api";
import type { ApiEmployee } from "@/types/users";
import EditUserModal from "./EditUserModal";
import AdjustScoreModal from "./AdjustScoreModal";
import AvatarUploadModal from "./AvatarUploadModal";
import SetPasswordModal from "./SetPasswordModal";
import UserAvatar from "@/components/ui/UserAvatar";
import { useAuthStore } from "@/store/authStore";
import { useAvatarStore } from "@/store/avatarStore";
import { apiMessage } from "@/lib/apiMessage";
import { DepartmentManagerModal } from "./DepartmentManagerModal";
const UserActionsModal = dynamic(() => import("./UserActionsModal"), { ssr: false });
import {
    EMPTY_TITLES,
    formatDate,
    getErrorMessage,
    useLoggedUserId,
    useMountedOnce,
    type UserCardProps,
} from "./userCardUtils";

export type { UserInfo, UserCardProps } from "./userCardUtils";

function UserCard({
    employee,
    departmentName = null,
    activeTaskTitles = EMPTY_TITLES,
    hasActiveTasks = false,
    userInfo = null,
    score = null,
    onDelete,
    onUpdated,
    onScoreChanged,
}: UserCardProps) {
    const aliveRef = useRef(true);

    useEffect(() => {
        aliveRef.current = true;
        return () => {
            aliveRef.current = false;
        };
    }, []);


    const [isDeleting, setIsDeleting] = useState(false);
    const [deleteError, setDeleteError] = useState("");
    const [showEdit, setShowEdit] = useState(false);
    const [showAdjust, setShowAdjust] = useState(false);
    const [showManager, setShowManager] = useState(false);
    const [showMobileSheet, setShowMobileSheet] = useState(false);
    const [showPasswordModal, setShowPasswordModal] = useState(false);
    const [showAvatarModal, setShowAvatarModal] = useState(false);
    const loggedUserType = useAuthStore((state) => state.userType);
    const setMyAvatar = useAvatarStore((state) => state.setMyAvatar);
    const canManageProfile = loggedUserType === 1;

    const editMounted = useMountedOnce(showEdit);
    const sheetMounted = useMountedOnce(showMobileSheet);

    const phoneNumber = userInfo?.phone ?? null;
    const userId = userInfo?.id ?? employee.user_id ?? employee.user ?? null;

    const [isActive, setIsActive] = useState<boolean>(
        userInfo?.isActive ??
        (employee as unknown as { is_active?: boolean }).is_active ??
        true
    );
    const [togglingActive, setTogglingActive] = useState(false);

    useEffect(() => {
        if (typeof userInfo?.isActive === "boolean") setIsActive(userInfo.isActive);
    }, [userInfo?.isActive]);

    const loggedUserId = useLoggedUserId();
    const isSelf = userId !== null && loggedUserId !== null && loggedUserId === userId;

    const isAdmin = employee.type === 1;
    const canDelete = !isAdmin && !isSelf && !hasActiveTasks;

    const deleteTooltipText = useMemo(() => {
        if (isAdmin) return "امکان حذف مدیر سیستم وجود ندارد";
        if (isSelf) return "شما نمی‌توانید حساب خود را حذف کنید";
        if (hasActiveTasks) return "این کاربر دارای تسک فعال است";
        return "حذف کاربر";
    }, [isAdmin, isSelf, hasActiveTasks]);

    const formattedDate = useMemo(
        () => formatDate(employee.created_at),
        [employee.created_at]
    );

    const handleToggleActive = useCallback(async () => {
        if (togglingActive || !userId || isSelf) return;

        const nextState = !isActive;
        setTogglingActive(true);

        try {
            await accountsApi.users.update(userId, {
                username: employee.username,
                phone_number: phoneNumber || "",
                type: employee.type ?? 2,
                is_active: nextState,
            });

            if (aliveRef.current) setIsActive(nextState);
            onUpdated({
                ...employee,
                is_active: nextState,
            } as ApiEmployee);
        } catch (err) {
            console.error("خطا در تغییر وضعیت حساب:", err);
        } finally {
            if (aliveRef.current) setTogglingActive(false);
        }
    }, [togglingActive, userId, isSelf, isActive, employee, phoneNumber, onUpdated]);

    const handleDelete = useCallback(async () => {
        if (!canDelete) return;
        setIsDeleting(true);
        setDeleteError("");

        try {
            const normalizedUsername = (employee.username || "").trim().toLowerCase();

            const [users, matchedEmployee] = await Promise.all([
                accountsApi.users.lookup(normalizedUsername).catch(() => []),
                accountsApi.employees.get(employee.id).catch(() => null),
            ]);

            const matchedUser = users.find(
                (user) => user.username?.trim().toLowerCase() === normalizedUsername
            );

            const employeeDeleteId = matchedEmployee?.id;
            const userDeleteId = matchedUser?.id;

            if (!employeeDeleteId && !userDeleteId) {
                throw new Error("شناسه حذف کاربر پیدا نشد");
            }

            if (employeeDeleteId) {
                await accountsApi.employees.remove(employeeDeleteId);
            }

            if (userDeleteId && matchedUser?.type !== 1) {
                await accountsApi.users.remove(userDeleteId);
            }

            onDelete(employee.id);
            if (aliveRef.current) setShowMobileSheet(false);
        } catch (err) {
            if (aliveRef.current) {
                setDeleteError(getErrorMessage(err, "حذف کاربر با خطا مواجه شد"));
            }
        } finally {
            if (aliveRef.current) setIsDeleting(false);
        }
    }, [canDelete, employee.id, employee.username, onDelete]);

    return (
        <>
            <div
                dir="rtl"
                className="user-card relative z-[1] flex flex-col gap-3 rounded-2xl border border-black/[0.06] bg-[#fafafa] p-4 transition-shadow duration-200 dark:border-white/[0.06] dark:bg-white/[0.02]"
            >

                <div className="absolute left-3 top-3 z-10 flex items-center gap-2">
                    <button
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation();
                            setShowMobileSheet(true);
                        }}
                        className="flex h-7 w-7 items-center justify-center rounded-full bg-black/5 text-gray-500 transition-transform active:scale-95 dark:bg-white/10 dark:text-gray-300"
                        aria-label="گزینه‌ها"
                    >
                        <MoreVertical size={15} />
                    </button>

                    {score !== null && (
                        <div
                            className="flex items-center gap-1 rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-bold text-amber-600 dark:border-amber-500/25 dark:bg-amber-500/[0.14] dark:text-amber-400"
                            title="امتیاز عملکرد"
                        >
                            <Star size={12} fill="currentColor" />
                            <span>{score}</span>
                        </div>
                    )}
                </div>


                <div className="flex items-center gap-3 pt-1">
                    <UserAvatar src={employee.avatar} name={employee.full_name || "؟"} id={employee.id} />
                    <div className="flex min-w-0 flex-col gap-0.5">
                        <p className="truncate text-[13.5px] font-bold leading-tight text-gray-800 dark:text-gray-100">
                            {employee.full_name || "بدون نام"}
                        </p>
                        <p className="text-[11px] font-medium text-gray-400 dark:text-gray-500">
                            @{employee.username}
                        </p>
                    </div>
                </div>


                <div className="flex flex-col gap-2 border-t border-black/5 pt-2.5 dark:border-white/5">
                    {phoneNumber && (
                        <div className="flex items-center gap-2 text-[11.5px] text-gray-400 dark:text-gray-500">
                            <Phone className="h-3.5 w-3.5 shrink-0" />
                            <span dir="ltr">{phoneNumber}</span>
                        </div>
                    )}

                    <div className="flex items-center justify-between text-[11.5px] text-gray-400 dark:text-gray-500">
                        <div className="flex min-w-0 items-center gap-1.5">
                            <ShieldCheck className="h-3.5 w-3.5 shrink-0" />
                            <span className="truncate">
                                {isAdmin ? "ادمین سیستم" : "کارمند"}
                                {departmentName ? ` • ${departmentName}` : ""}
                            </span>
                        </div>

                        <div className="flex shrink-0 items-center gap-1.5">
                            <CalendarDays className="h-3.5 w-3.5" />
                            <span>{formattedDate}</span>
                        </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                        <span
                            className={`rounded-lg border bg-gradient-to-br px-2 py-0.5 text-[10.5px] font-bold ${isAdmin
                                ? "border-amber-500/25 from-amber-500/[0.18] to-amber-600/[0.18] text-amber-600 dark:text-amber-400"
                                : "border-indigo-500/25 from-indigo-500/[0.18] to-violet-500/[0.18] text-indigo-500 dark:text-indigo-300"
                                }`}
                        >
                            {isAdmin ? "مدیر کل" : "کاربر سامانه"}
                        </span>

                        {hasActiveTasks && (
                            <span className="rounded-lg border border-rose-500/25 bg-rose-50 px-2 py-0.5 text-[10.5px] font-bold text-rose-600 dark:bg-rose-500/10 dark:text-rose-400">
                                {activeTaskTitles.length > 0
                                    ? `${activeTaskTitles.length} تسک فعال`
                                    : "دارای تسک"}
                            </span>
                        )}
                    </div>
                </div>
            </div>


            {sheetMounted && (
                <UserActionsModal
                    open={showMobileSheet}
                    name={employee.full_name || employee.username}
                    isActive={isActive}
                    togglingActive={togglingActive}
                    isSelf={isSelf}
                    isAdmin={isAdmin}
                    canDelete={canDelete}
                    deleteHint={deleteTooltipText}
                    canManageProfile={canManageProfile}
                    hasUserId={userId !== null}
                    isDeleting={isDeleting}
                    deleteError={deleteError}
                    onClose={() => setShowMobileSheet(false)}
                    onToggleActive={handleToggleActive}
                    onEdit={() => setShowEdit(true)}
                    onAdjust={() => setShowAdjust(true)}
                    onManager={() => setShowManager(true)}
                    onPassword={() => setShowPasswordModal(true)}
                    onAvatar={() => setShowAvatarModal(true)}
                    onConfirmDelete={handleDelete}
                />
            )}

            <AnimatePresence>
                {showManager && (
                    <DepartmentManagerModal
                        key={`manager-modal-${employee.id}`}
                        employeeId={employee.id}
                        employeeName={employee.full_name || employee.username}
                        onClose={() => setShowManager(false)}
                    />
                )}
            </AnimatePresence>


            {editMounted && (
                <EditUserModal
                    isOpen={showEdit}
                    onClose={() => setShowEdit(false)}
                    employee={employee}
                    onUpdated={(updatedEmployee: ApiEmployee) => {
                        onUpdated(updatedEmployee);
                        setShowEdit(false);
                    }}
                />
            )}


            {userId != null && (
                <SetPasswordModal open={showPasswordModal} userId={userId} userName={employee.full_name || employee.username} onClose={() => setShowPasswordModal(false)} />
            )}
            {showAvatarModal && userId != null && (
                <AvatarUploadModal
                    open={showAvatarModal}
                    onClose={() => setShowAvatarModal(false)}
                    userId={userId}
                    userName={employee.full_name || employee.username}
                    current={employee.avatar}
                    onUpload={async (file) => {
                        try {
                            const avatar = await accountsApi.users.uploadAvatar(userId, file);
                            onUpdated({ ...employee, avatar });
                            if (isSelf) setMyAvatar(avatar);
                            else setMyAvatar(useAvatarStore.getState().myAvatar);
                        } catch (error) { throw new Error(apiMessage(error, "آپلود عکس انجام نشد")); }
                    }}
                    onRemove={async () => {
                        try {
                            await accountsApi.users.removeAvatar(userId);
                            onUpdated({ ...employee, avatar: null });
                            if (isSelf) setMyAvatar(null);
                            else setMyAvatar(useAvatarStore.getState().myAvatar);
                        } catch (error) { throw new Error(apiMessage(error, "حذف عکس انجام نشد")); }
                    }}
                />
            )}
            <AdjustScoreModal
                isOpen={showAdjust}
                employeeId={employee.id}
                employeeName={employee.full_name || employee.username}
                currentScore={score}
                onClose={() => setShowAdjust(false)}
                onSuccess={(action, amount) =>
                    onScoreChanged?.(employee.id, action, amount)
                }
            />
        </>
    );
}

export default memo(UserCard);
