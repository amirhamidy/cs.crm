"use client";

import { useEffect, useState, forwardRef, InputHTMLAttributes } from "react";
import { m, AnimatePresence, useReducedMotion } from "framer-motion";
import { Backdrop } from "@/components/ui/Backdrop";
import { panelMotion } from "@/lib/motion";
import { X, GitBranch, CheckCircle2 } from "lucide-react";
import { Department } from "./types";

import { BusyContent } from "@/components/ui/Button";
interface StagePayload {
    department: number;
    name: string;
    order: number;
}

interface Props {
    open: boolean;
    department: Department | null;
    defaultOrder?: number;
    onClose: () => void;
    onSubmit: (data: StagePayload) => Promise<void>;
}

interface FloatingInputProps extends InputHTMLAttributes<HTMLInputElement> { label: string; id: string; }

const FloatingInput = forwardRef<HTMLInputElement, FloatingInputProps>(({ label, id, className = "", ...props }, ref) => (
    <div className="relative">
        <input ref={ref} id={id} placeholder=" " className={`peer w-full border border-gray-200 rounded-4xl px-5 py-3 text-sm text-black outline-none transition-all duration-200 focus:border-gray-400 dark:bg-white/[0.04] dark:border-white/[0.08] dark:text-white dark:focus:border-blue-500 ${className}`} {...props} />
        <label htmlFor={id} className="absolute right-5 top-1/2 -translate-y-1/2 text-sm text-gray-400 pointer-events-none transition-all duration-200 bg-white dark:bg-[#111827] px-1.5 rounded peer-focus:top-0 peer-focus:text-xs peer-focus:text-gray-500 peer-[:not(:placeholder-shown)]:top-0 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:text-gray-500">{label}</label>
    </div>
));
FloatingInput.displayName = "FloatingInput";

export default function AddStageModal({ open, department, defaultOrder = 0, onClose, onSubmit }: Props) {
    const reduced = useReducedMotion() ?? false;
    const [name, setName] = useState("");
    const [order, setOrder] = useState(defaultOrder);
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);

    useEffect(() => { if (open) setOrder(defaultOrder); }, [open, defaultOrder]);

    useEffect(() => {
        if (!open) return;
        const onKey = (e: KeyboardEvent) => { if (e.key === "Escape" && !loading && !success) handleClose(); };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, [open, loading, success]);

    const resetForm = () => { setName(""); setOrder(defaultOrder); };

    const handleClose = () => {
        if (loading || success) return;
        resetForm();
        onClose();
    };

    const handleSubmit = async (e?: React.FormEvent) => {
        e?.preventDefault();
        if (!name.trim() || !department || loading) return;
        setLoading(true);
        try {
            await onSubmit({ department: Number(department.id), name: name.trim(), order });
            setSuccess(true);
            setTimeout(() => { setSuccess(false); resetForm(); onClose(); }, 1400);
        } finally {
            setLoading(false);
        }
    };

    return (
        <AnimatePresence>
            {open && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
<Backdrop onClick={handleClose} />
                    <m.div {...panelMotion(false, reduced)} className="relative bg-white dark:bg-[#111827] rounded-[2rem] shadow-sm border border-gray-100 dark:border-white/[0.06] w-full max-w-sm overflow-hidden" dir="rtl">
                        <div className="px-8 pt-8 pb-6 flex items-center justify-between">
                            <div className="flex items-center gap-2.5">
                                <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-500/10 flex items-center justify-center"><GitBranch size={15} className="text-indigo-500" /></div>
                                <div>
                                    <h3 className="text-[14px] font-extrabold text-gray-900 dark:text-white">فرآیند جدید</h3>
                                    <p className="text-[11px] text-gray-400 mt-0.5">{department?.name ?? ""}</p>
                                </div>
                            </div>
                            <button type="button" onClick={handleClose} disabled={loading || success} className="w-8 h-8 rounded-xl flex items-center justify-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors disabled:opacity-40 bg-gray-100 dark:bg-white/[0.05]"><X size={15} /></button>
                        </div>

                        <form onSubmit={handleSubmit} className="px-8 pb-8 flex flex-col gap-4">
                            <FloatingInput label="نام فرآیند" id="stage_name" value={name} onChange={(e) => setName(e.target.value)} disabled={loading || success} dir="rtl" />

                            <AnimatePresence mode="wait">
                                {success ? (
                                    <m.div key="success" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }} className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-green-50 dark:bg-green-500/10 text-green-600 dark:text-green-400 text-sm font-medium">
                                        <CheckCircle2 size={16} />
                                        فرآیند با موفقیت اضافه شد
                                    </m.div>
                                ) : (
                                    <m.button key="submit" type="submit" disabled={!name.trim() || loading} whileTap={{ scale: 0.97 }} className="relative bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold rounded-full py-3 text-sm transition-colors flex items-center justify-center">
                                        <BusyContent busy={loading}>
                                            افزودن فرآیند
                                        </BusyContent>
                                    </m.button>
                                )}
                            </AnimatePresence>
                        </form>
                    </m.div>
                </div>
            )}
        </AnimatePresence>
    );
}