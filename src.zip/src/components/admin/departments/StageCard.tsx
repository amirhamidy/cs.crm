"use client";

import { AnimatePresence, m } from "framer-motion";
import { ChevronLeft, Pencil, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { StageTasksSkeleton } from "@/components/ui/skeletons";
import { createPortal } from "react-dom";
import type { TaskStatus } from "@/types/task";
import type { Stage, Task } from "./types";
import TaskCard from "./TaskCard";

interface StageCardProps {
    stage: Stage;
    index: number;
    isLast: boolean;
    tasks: Task[];
    tasksLoading?: boolean;
    showHeader?: boolean;
    showConnector?: boolean;
    onEditStage?: (stage: Stage) => void;
    onDeleteStage?: (stage: Stage) => void;
    onAddTask?: (stage: Stage) => void;
    hasDependencies?: boolean;
    dependencyMessage?: string;
}

const STATUS_SUMMARY_CONFIG: Record<
    TaskStatus,
    {
        label: string;
        dot: string;
        text: string;
    }
> = {
    sold: {
        label: "فروش",
        dot: "bg-emerald-500",
        text: "text-emerald-600 dark:text-emerald-400",
    },
    completed: {
        label: "تکمیل",
        dot: "bg-blue-500",
        text: "text-blue-600 dark:text-blue-400",
    },
    in_progress: {
        label: "درحال انجام",
        dot: "bg-amber-500",
        text: "text-amber-600 dark:text-amber-400",
    },
    cancelled: {
        label: "لغو",
        dot: "bg-red-500",
        text: "text-red-600 dark:text-red-400",
    },
};

export default function StageCard({
    stage,
    index,
    isLast,
    tasks,
    tasksLoading = false,
    showHeader = true,
    showConnector = true,
    onEditStage,
    onDeleteStage,
    onAddTask,
    hasDependencies = false,
    dependencyMessage = "این فرآیند وابستگی دارد",
}: StageCardProps) {
    const stageColor =
        stage.color ?? "#6366f1";

    const [tooltipVisible, setTooltipVisible] =
        useState(false);

    const [tooltipPosition, setTooltipPosition] =
        useState({
            top: 0,
            left: 0,
        });

    const statusCounts = (
        tasks ?? []
    ).reduce<Record<string, number>>(
        (acc, task) => {
            if (
                task.status &&
                typeof task.status === "string"
            ) {
                acc[task.status] =
                    (acc[task.status] ?? 0) + 1;
            }

            return acc;
        },
        {}
    );

    const showDependencyTooltip = (
        event: React.MouseEvent<HTMLButtonElement>
    ) => {
        if (!hasDependencies) {
            return;
        }

        const rect =
            event.currentTarget.getBoundingClientRect();

        setTooltipPosition({
            top: rect.top - 10,
            left:
                rect.left +
                rect.width / 2,
        });

        setTooltipVisible(true);
    };

    const hideDependencyTooltip = () => {
        setTooltipVisible(false);
    };

    const tooltip =
        tooltipVisible &&
            hasDependencies &&
            typeof document !== "undefined"
            ? createPortal(
                <AnimatePresence>
                    <m.div
                        initial={{
                            opacity: 0,
                            y: 5,
                            scale: 0.95,
                        }}
                        animate={{
                            opacity: 1,
                            y: 0,
                            scale: 1,
                        }}
                        exit={{
                            opacity: 0,
                            y: 5,
                            scale: 0.95,
                        }}
                        transition={{
                            duration: 0.15,
                            ease: "easeOut",
                        }}
                        className="pointer-events-none fixed z-[999999] -translate-x-1/2 -translate-y-full whitespace-nowrap"
                        style={{
                            top: tooltipPosition.top,
                            left: tooltipPosition.left,
                        }}
                        dir="rtl"
                    >
                        <div className="flex flex-col items-center gap-0.5 rounded-xl border border-white/[0.08] bg-gray-800 px-3 py-2 text-center shadow-2xl">
                            <span className="text-[11px] font-extrabold text-white">
                                {dependencyMessage}
                            </span>

                            <span className="text-[10px] text-gray-400">
                                برای حذف، ابتدا وظایف این فرآیند را حذف کنید
                            </span>
                        </div>
                    </m.div>
                </AnimatePresence>,
                document.body
            )
            : null;

    return (
        <>
            <m.div
                layout
                initial={{
                    opacity: 0,
                    y: 8,
                }}
                animate={{
                    opacity: 1,
                    y: 0,
                }}
                exit={{
                    opacity: 0,
                    scale: 0.97,
                }}
                transition={{
                    layout: {
                        type: "spring",
                        stiffness: 300,
                        damping: 30,
                    },
                    opacity: {
                        duration: 0.2,
                    },
                }}
                className="relative flex min-w-0 flex-col rounded-[1.45rem] border shadow-[0_6px_22px_rgba(15,23,42,0.025)] dark:bg-white/[0.025] dark:shadow-none"
                style={{
                    borderColor: `${stageColor}25`,
                }}
            >
                {showConnector && !isLast && (
                    <div
                        className="pointer-events-none absolute top-[28px] z-20 flex h-5 w-5 items-center justify-center rounded-full border bg-white shadow-sm dark:bg-[#111827]"
                        style={{
                            insetInlineEnd: "-10px",
                            borderColor: `${stageColor}35`,
                            color: stageColor,
                        }}
                    >
                        <ChevronLeft
                            size={10}
                            strokeWidth={2.5}
                        />
                    </div>
                )}

                {showHeader && (
                    <div
                        className="relative px-3 py-2.5"
                    >
                        <div className="flex items-center justify-between gap-2.5">
                            <div className="flex min-w-0 items-center gap-2">
                                <span
                                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[11px] font-extrabold text-white shadow-sm"
                                    style={{
                                        backgroundColor:
                                            stageColor,
                                    }}
                                >
                                    {index + 1}
                                </span>

                                <div className="min-w-0 ">
                                    <div className="flex min-w-0 items-center gap-1.5">
                                        <h4 className="truncate text-[12px] font-extrabold text-gray-800 dark:text-gray-100">
                                            {stage.name}
                                        </h4>

                                        <span
                                            className="shrink-0 rounded-full px-1.5 py-0.5 text-[10.5px] font-extrabold"
                                            style={{
                                                background:
                                                    `${stageColor}12`,
                                                color:
                                                    stageColor,
                                            }}
                                        >
                                            {tasks?.length ??
                                                0}
                                        </span>
                                    </div>

                                    {stage.description && (
                                        <p className="mt-0.5 line-clamp-1 text-[11px] font-medium text-gray-400 dark:text-gray-500">
                                            {
                                                stage.description
                                            }
                                        </p>
                                    )}

                                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5">
                                        <span className="text-[11px] font-bold text-gray-400 dark:text-gray-500">
                                            وظیفه
                                        </span>

                                        {Object.entries(
                                            statusCounts
                                        ).map(
                                            ([
                                                status,
                                                count,
                                            ]) => {
                                                const config =
                                                    STATUS_SUMMARY_CONFIG[
                                                    status as TaskStatus
                                                    ];

                                                if (
                                                    !config ||
                                                    count ===
                                                    0
                                                ) {
                                                    return null;
                                                }

                                                return (
                                                    <span
                                                        key={
                                                            status
                                                        }
                                                        className={`flex items-center gap-1 text-[11px] font-bold ${config.text}`}
                                                    >
                                                        <span className="relative flex h-1.5 w-1.5">
                                                            {status ===
                                                                "in_progress" && (
                                                                    <span
                                                                        className={`absolute inline-flex h-full w-full animate-ping rounded-full ${config.dot} opacity-60`}
                                                                    />
                                                                )}

                                                            <span
                                                                className={`relative inline-flex h-1.5 w-1.5 rounded-full ${config.dot}`}
                                                            />
                                                        </span>

                                                        {count}
                                                    </span>
                                                );
                                            }
                                        )}
                                    </div>
                                </div>
                            </div>

                            <div className="flex shrink-0 items-center gap-1 ">
                                {onAddTask && (
                                    <button
                                        type="button"
                                        onClick={() =>
                                            onAddTask(
                                                stage
                                            )
                                        }
                                        className="flex h-7 w-7 items-center justify-center rounded-lg text-gray-400 transition hover:bg-black/5 hover:text-gray-700 dark:hover:bg-white/10 dark:hover:text-white"
                                    >
                                        <Plus
                                            size={12}
                                        />
                                    </button>
                                )}

                                {onEditStage && (
                                    <button
                                        type="button"
                                        onClick={() =>
                                            onEditStage(
                                                stage
                                            )
                                        }
                                        className="flex h-7 w-7 items-center justify-center rounded-lg transition"
                                        style={{
                                            color:
                                                stageColor,
                                            backgroundColor:
                                                `${stageColor}12`,
                                        }}
                                    >
                                        <Pencil
                                            size={12}
                                        />
                                    </button>
                                )}

                                {onDeleteStage && (
                                    <button
                                        type="button"
                                        onClick={() => {
                                            if (
                                                hasDependencies
                                            ) {
                                                return;
                                            }

                                            onDeleteStage(
                                                stage
                                            );
                                        }}
                                        onMouseEnter={
                                            showDependencyTooltip
                                        }
                                        onMouseLeave={
                                            hideDependencyTooltip
                                        }
                                        className="flex h-7 w-7 items-center justify-center rounded-lg transition"
                                        style={{
                                            background:
                                                hasDependencies
                                                    ? "rgba(0,0,0,0.035)"
                                                    : undefined,
                                            color:
                                                hasDependencies
                                                    ? "#9ca3af"
                                                    : "#9ca3af",
                                            cursor:
                                                hasDependencies
                                                    ? "not-allowed"
                                                    : "pointer",
                                        }}
                                    >
                                        <Trash2
                                            size={12}
                                        />
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                <div
                    className="h-px"
                    style={{
                        background: `${stageColor}12`,
                    }}
                />

                {tasksLoading ? (
                    <StageTasksSkeleton />
                ) : !tasks ||
                    tasks.length === 0 ? (
                    <div className="flex h-28 flex-col items-center justify-center gap-1.5 px-4 text-center">
                        <div
                            className="flex h-7 w-7 items-center justify-center rounded-lg"
                            style={{
                                background:
                                    `${stageColor}0c`,
                            }}
                        >
                            <Plus
                                size={11}
                                style={{
                                    color: `${stageColor}80`,
                                }}
                            />
                        </div>

                        <p className="text-[11px] font-medium text-gray-400">
                            وظیفه‌ای در این مرحله نیست
                        </p>
                    </div>
                ) : (
                    <div className="scrollbar-thin flex max-h-[420px] flex-col gap-2 overflow-y-auto p-2">
                        {tasks.map(
                            (
                                task,
                                taskIndex
                            ) => (
                                <m.div
                                    key={task.id}
                                    initial={{
                                        opacity: 0,
                                        y: 5,
                                    }}
                                    animate={{
                                        opacity: 1,
                                        y: 0,
                                    }}
                                    transition={{
                                        delay: Math.min(
                                            taskIndex,
                                            6
                                        ) * 0.025,
                                        duration: 0.18,
                                    }}
                                >
                                    <TaskCard
                                        task={task}
                                        accent={
                                            stageColor
                                        }
                                    />
                                </m.div>
                            )
                        )}
                    </div>
                )}
            </m.div>

            {tooltip}
        </>
    );
}