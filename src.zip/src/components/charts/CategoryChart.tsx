"use client";

import { AnimatePresence, m } from "framer-motion";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";

type TimeRange = "weekly" | "monthly" | "yearly";

interface SourceCount {
  resourceId: number;
  name: string;
  value: number;
  color: string;
  glow: string;
}

type CategoryChartData = Record<TimeRange, SourceCount[]>;

const ranges: { key: TimeRange; label: string; sub: string }[] = [
  { key: "weekly", label: "هفتگی", sub: "۷ روز اخیر" },
  { key: "monthly", label: "ماهانه", sub: "۳۰ روز اخیر" },
  { key: "yearly", label: "سالانه", sub: "۳۶۵ روز اخیر" },
];

type ActiveSlice = {
  id: number;
  label: string;
  value: number;
  color: string;
  glow: string;
  pct: string;
};

export default function CategoryChart({
  data: rangeData,
}: {
  data: CategoryChartData;
}) {
  const [activeRange, setActiveRange] = useState<TimeRange>("weekly");

  const [activeSlice, setActiveSlice] =
    useState<ActiveSlice | null>(null);

  const data = useMemo(
    () => rangeData[activeRange] ?? [],
    [rangeData, activeRange],
  );

  const total = useMemo(
    () => data.reduce((sum, item) => sum + item.value, 0),
    [data],
  );

  const totalFormatted = useMemo(
    () => total.toLocaleString("fa-IR"),
    [total],
  );

  const currentRange = useMemo(
    () => ranges.find((range) => range.key === activeRange),
    [activeRange],
  );

  const handleMouseEnter = useCallback(
    (_: unknown, index: number) => {
      const item = data[index];

      if (!item) return;

      setActiveSlice({
        id: item.resourceId,
        label: item.name,
        value: item.value,
        color: item.color,
        glow: item.glow,
        pct: total
          ? ((item.value / total) * 100).toFixed(1)
          : "0.0",
      });
    },
    [data, total],
  );

  const handleMouseLeave = useCallback(() => {
    setActiveSlice(null);
  }, []);

  useEffect(() => {
    setActiveSlice(null);
  }, [activeRange]);

  const pieDefs = (
    <defs>
      {data.map((item) => (
        <radialGradient
          key={`pieGrad-${item.resourceId}`}
          id={`pieGrad-${item.resourceId}`}
          cx="50%"
          cy="50%"
          r="50%"
        >
          <stop offset="0%" stopColor={item.color} stopOpacity={1} />
          <stop
            offset="100%"
            stopColor={item.color}
            stopOpacity={0.65}
          />
        </radialGradient>
      ))}

      {data.map((item) => (
        <filter
          key={`glow-${item.resourceId}`}
          id={`glow-${item.resourceId}`}
          x="-20%"
          y="-20%"
          width="140%"
          height="140%"
        >
          <feDropShadow
            dx="0"
            dy="0"
            stdDeviation="3"
            floodColor={item.color}
            floodOpacity="0.6"
          />
        </filter>
      ))}
    </defs>
  );

  return (
    <div className="relative rounded-2xl border border-gray-100 bg-white p-4 shadow-sm dark:border-white/5 dark:bg-gray-950">
      <div className="mb-3 flex items-start justify-between gap-3" dir="rtl">
        <div>
          <h3 className="text-[14px] font-semibold text-gray-900 dark:text-white">
            بیشترین منابع مشتری
          </h3>

          <p className="mt-0.5 text-[13px] text-gray-500 dark:text-gray-400">
            {currentRange?.sub}
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-xl border border-gray-100 bg-gray-50/80 p-1 dark:border-white/5 dark:bg-gray-900/50">
          {ranges.map((range) => (
            <button
              key={range.key}
              type="button"
              onClick={() => setActiveRange(range.key)}
              className="relative rounded-lg px-2.5 py-1 text-[11px] font-medium"
            >
              {activeRange === range.key && (
                <m.span
                  layoutId="categoryChartRangeIndicator"
                  className="absolute inset-0 rounded-lg bg-white shadow-sm dark:bg-gray-800"
                  transition={{
                    type: "spring",
                    stiffness: 400,
                    damping: 30,
                  }}
                />
              )}

              <span
                className={`relative z-10 transition-colors ${activeRange === range.key
                    ? "text-gray-900 dark:text-white"
                    : "text-gray-500 dark:text-gray-400"
                  }`}
              >
                {range.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="relative h-[180px]">
        <div className="absolute left-2 top-2 z-10 min-w-[140px]">
          <AnimatePresence mode="wait">
            {activeSlice && (
              <m.div
                key={`${activeRange}-${activeSlice.id}`}
                initial={{
                  opacity: 0,
                  y: 4,
                  scale: 0.96,
                }}
                animate={{
                  opacity: 1,
                  y: 0,
                  scale: 1,
                }}
                exit={{
                  opacity: 0,
                  y: 4,
                  scale: 0.96,
                }}
                transition={{ duration: 0.15 }}
                className="pointer-events-none rounded-xl border border-gray-200/60 bg-white/95 px-3 py-2 shadow-lg dark:border-white/10 dark:bg-gray-900/95"
                style={{
                  boxShadow: `0 4px 20px ${activeSlice.glow}`,
                }}
              >
                <div className="mb-1 flex items-center gap-1.5">
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{
                      backgroundColor: activeSlice.color,
                    }}
                  />

                  <span className="text-[12px] font-semibold text-gray-800 dark:text-gray-100">
                    {activeSlice.label}
                  </span>
                </div>

                <p className="text-[11px] text-gray-500 dark:text-gray-400">
                  سهم منبع:{" "}
                  <span
                    className="font-bold tabular-nums"
                    style={{
                      color: activeSlice.color,
                    }}
                  >
                    {activeSlice.pct}%
                  </span>
                </p>
              </m.div>
            )}
          </AnimatePresence>
        </div>

        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            {pieDefs}

            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              innerRadius={48}
              outerRadius={74}
              paddingAngle={data.length > 1 ? 4 : 0}
              strokeWidth={0}
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
              isAnimationActive={false}
            >
              {data.map((entry) => {
                const isActive =
                  activeSlice?.id === entry.resourceId;

                return (
                  <Cell
                    key={`${activeRange}-${entry.resourceId}`}
                    fill={`url(#pieGrad-${entry.resourceId})`}
                    stroke="none"
                    filter={
                      isActive
                        ? `url(#glow-${entry.resourceId})`
                        : undefined
                    }
                  />
                );
              })}
            </Pie>
          </PieChart>
        </ResponsiveContainer>

        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {activeSlice ? (
              <m.div
                key={activeSlice.id}
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.85 }}
                transition={{ duration: 0.12 }}
                className="text-center"
              >
                <p
                  className="text-[20px] font-bold tabular-nums"
                  style={{
                    color: activeSlice.color,
                  }}
                >
                  {activeSlice.pct}%
                </p>
              </m.div>
            ) : (
              <m.div
                key="total"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.12 }}
                className="text-center"
              >
                <p className="text-[10px] text-gray-400 dark:text-gray-500">
                  کل
                </p>

                <p className="text-[16px] font-bold tabular-nums text-gray-700 dark:text-gray-200">
                  {totalFormatted}
                </p>
              </m.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="mt-2 grid grid-cols-2 gap-1" dir="rtl">
        {data.map((entry: SourceCount) => {
          const pct = total
            ? ((entry.value / total) * 100).toFixed(1)
            : "0.0";

          const isActive =
            activeSlice?.id === entry.resourceId;

          return (
            <div
              key={`${activeRange}-${entry.resourceId}`}
              className="flex cursor-default items-center gap-1.5 rounded-lg px-2 py-1 transition-colors duration-150"
              style={{
                backgroundColor: isActive
                  ? entry.glow
                  : "transparent",
              }}
            >
              <span
                className="h-2 w-2 flex-shrink-0 rounded-full"
                style={{
                  backgroundColor: entry.color,
                }}
              />

              <span className="flex-1 truncate text-[12px] text-gray-600 dark:text-gray-300">
                {entry.name}
              </span>

              <span
                className="tabular-nums text-[12px] font-bold"
                style={{
                  color: entry.color,
                }}
              >
                {pct}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}