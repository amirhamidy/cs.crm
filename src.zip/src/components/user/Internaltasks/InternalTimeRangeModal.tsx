"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, m, useReducedMotion } from "framer-motion";
import { X, ChevronDown, ChevronLeft, ChevronRight, Clock, Check, CalendarDays } from "lucide-react";
import { toJalali, toGregorian, jalaliMonthLength, jalaliWeekday, JALALI_MONTHS, JALALI_WEEKDAYS, toPersianDigits, pad2, todayJalali } from "@/lib/jalali";

import { BusyContent } from "@/components/ui/Button";
import { ModalLayer } from "@/components/ui/ModalLayer";
import { Backdrop } from "@/components/ui/Backdrop";
import { panelMotion } from "@/lib/motion";
interface FieldState {
    jy: number;
    jm: number;
    jd: number;
    hour: number;
    minute: number;
}

interface TimeRangeModalProps {
    open: boolean;
    initialStartedAt?: string | null;
    initialDeadline?: string | null;
    loading?: boolean;
    onClose: () => void;
    onSubmit: (startedAt: string, deadline: string) => Promise<void>;
    error?: string | null;
}

function parseIsoToField(iso?: string | null): FieldState {
    const d = iso ? new Date(iso) : new Date();

    const [jy, jm, jd] = toJalali(
        d.getFullYear(),
        d.getMonth() + 1,
        d.getDate()
    );

    return {
        jy,
        jm,
        jd,
        hour: d.getHours(),
        minute: d.getMinutes(),
    };
}

function fieldToIso(f: FieldState) {
    const [gy, gm, gd] = toGregorian(f.jy, f.jm, f.jd);

    return new Date(
        gy,
        gm - 1,
        gd,
        f.hour,
        f.minute,
        0
    ).toISOString();
}

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const MINUTES = Array.from({ length: 12 }, (_, i) => i * 5);

interface NiceSelectOption {
    value: number;
    label: string;
}

function NiceSelect({
    value,
    onChange,
    options,
    label,
}: {
    value: number;
    onChange: (value: number) => void;
    options: NiceSelectOption[];
    label: string;
}) {
    const [isOpen, setIsOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);
    const selectedOption =
        options.find((option) => option.value === value) || options[0];

    useEffect(() => {
        function handleClick(event: MouseEvent) {
            if (ref.current && !ref.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClick);
        return () => document.removeEventListener("mousedown", handleClick);
    }, []);

    return (
        <div className="relative flex-1" ref={ref}>
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="flex w-full items-center justify-between rounded-2xl border border-gray-200 bg-white px-5 py-3 text-sm text-black outline-none transition-all duration-200 focus:border-gray-400 dark:border-white/[0.08] dark:bg-white/[0.04] dark:text-white dark:focus:border-indigo-500"
            >
                <span
                    className={
                        selectedOption
                            ? "text-black dark:text-white"
                            : "text-gray-400"
                    }
                >
                    {selectedOption ? selectedOption.label : label}
                </span>
                <ChevronDown
                    size={16}
                    className={`text-gray-400 transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
            </button>
            <label
                className={`pointer-events-none absolute right-5 rounded bg-white px-1.5 text-sm text-gray-400 transition-all duration-200 dark:bg-[#111827] ${isOpen || selectedOption
                    ? "top-0 text-xs text-gray-500 dark:text-gray-400"
                    : "top-1/2 -translate-y-1/2"
                    }`}
            >
                {label}
            </label>
            <AnimatePresence>
                {isOpen && (
                    <m.div
                        initial={{ opacity: 0, y: -10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -10, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute z-50 mt-2 max-h-60 w-full overflow-y-auto rounded-2xl border border-gray-100 bg-white p-1.5 shadow-[0_8px_30px_rgb(0,0,0,0.12)] dark:border-white/[0.06] dark:bg-[#111827]"
                        style={{ scrollbarWidth: "thin" }}
                    >
                        {options.map((option) => (
                            <button
                                key={option.value}
                                type="button"
                                onClick={() => {
                                    onChange(option.value);
                                    setIsOpen(false);
                                }}
                                className={`flex w-full items-center justify-between rounded-xl px-4 py-2.5 text-[13px] font-bold transition-colors ${option.value === value
                                    ? "bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-400"
                                    : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-white/[0.04]"
                                    }`}
                            >
                                {option.label}
                                {option.value === value && <Check size={14} />}
                            </button>
                        ))}
                    </m.div>
                )}
            </AnimatePresence>
        </div>
    );
}

export default function TimeRangeModal({
    open,
    initialStartedAt,
    initialDeadline,
    loading,
    onClose,
    onSubmit,
    error: externalError,
}: TimeRangeModalProps) {
    const [start, setStart] = useState<FieldState>(() =>
        parseIsoToField(initialStartedAt)
    );

    const [deadline, setDeadline] = useState<FieldState>(() =>
        parseIsoToField(initialDeadline)
    );

    const [activeField, setActiveField] = useState<
        "start" | "deadline"
    >("start");

    const [viewJy, setViewJy] = useState(start.jy);
    const [viewJm, setViewJm] = useState(start.jm);
    const [error, setError] = useState("");

    useEffect(() => {
        if (!open) return;

        const nextStart = parseIsoToField(initialStartedAt);
        const nextDeadline = parseIsoToField(initialDeadline);

        setStart(nextStart);
        setDeadline(nextDeadline);
        setActiveField("start");
        setViewJy(nextStart.jy);
        setViewJm(nextStart.jm);
        setError("");
    }, [open, initialStartedAt, initialDeadline]);

    useEffect(() => {
        const cur = activeField === "start" ? start : deadline;
        setViewJy(cur.jy);
        setViewJm(cur.jm);
    }, [activeField]);

    if (!open || typeof document === "undefined") return null;

    const current = activeField === "start" ? start : deadline;
    const setCurrent = activeField === "start" ? setStart : setDeadline;

    const weekdayOffset = jalaliWeekday(viewJy, viewJm, 1);
    const daysInMonth = jalaliMonthLength(viewJy, viewJm);

    const cells: (number | null)[] = [
        ...Array(weekdayOffset).fill(null),
        ...Array.from(
            { length: daysInMonth },
            (_, i) => i + 1
        ),
    ];

    function prevMonth() {
        if (viewJm === 1) {
            setViewJm(12);
            setViewJy((y) => y - 1);
        } else {
            setViewJm((m) => m - 1);
        }
    }

    function nextMonth() {
        if (viewJm === 12) {
            setViewJm(1);
            setViewJy((y) => y + 1);
        } else {
            setViewJm((m) => m + 1);
        }
    }

    function handleSubmit() {
        const s = fieldToIso(start);
        const d = fieldToIso(deadline);

        if (new Date(d) <= new Date(s)) {
            setError("مهلت انجام باید بعد از زمان شروع باشد");
            return;
        }

        setError("");
        onSubmit(s, d);
    }

    const [ty, tm, td] = todayJalali();

    const hoursOptions = HOURS.map((h) => ({
        value: h,
        label: toPersianDigits(pad2(h)),
    }));

    const minutesOptions = MINUTES.map((m) => ({
        value: m,
        label: toPersianDigits(pad2(m)),
    }));

    const reduced = useReducedMotion() ?? false;

    return createPortal(
        <AnimatePresence mode="wait">
            {open && (
                <ModalLayer
                    className="fixed inset-0 z-[99999] flex items-center justify-center px-4"
                    dir="rtl"
                >
                    <Backdrop onClick={onClose} />

                    <m.div
                        {...panelMotion(false, reduced)}
                        dir="rtl"
                        className="relative z-10 flex max-h-[90vh] w-full max-w-md flex-col overflow-hidden rounded-[2rem] border border-gray-100 bg-white shadow-[0_24px_70px_rgba(0,0,0,0.22)] dark:border-white/[0.06] dark:bg-[#111827]"
                    >
                        <div className="flex shrink-0 items-center justify-between px-8 pb-6 pt-8">
                            <div className="flex items-center gap-2.5">
                                <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-blue-50 dark:bg-blue-500/10">
                                    <Clock
                                        size={15}
                                        className="text-blue-500"
                                    />
                                </div>

                                <div>
                                    <h3 className="text-[14px] font-extrabold text-gray-900 dark:text-white">
                                        تعیین بازه زمانی
                                    </h3>

                                    <p className="mt-0.5 text-[11px] text-gray-400">
                                        شروع و مهلت انجام
                                    </p>
                                </div>
                            </div>

                            <button
                                type="button"
                                onClick={onClose}
                                className="flex h-8 w-8 items-center justify-center rounded-xl bg-gray-100 text-gray-400 transition-colors hover:text-gray-600 dark:bg-white/[0.05] dark:hover:text-gray-300"
                            >
                                <X size={15} />
                            </button>
                        </div>

                        <div className="flex-1 overflow-y-auto px-8 pb-2">
                            <div className="flex flex-col gap-4">
                                <div className="grid grid-cols-2 gap-2">
                                    {(["start", "deadline"] as const).map(
                                        (field) => {
                                            const f =
                                                field === "start"
                                                    ? start
                                                    : deadline;

                                            const active =
                                                activeField === field;

                                            return (
                                                <button
                                                    key={field}
                                                    type="button"
                                                    onClick={() =>
                                                        setActiveField(field)
                                                    }
                                                    className={`rounded-2xl border px-3 py-2.5 text-right transition-all duration-200 ${active
                                                        ? "border-blue-500 bg-blue-50/50 dark:border-blue-500/50 dark:bg-blue-500/[0.06]"
                                                        : "border-gray-100 bg-gray-50 hover:border-gray-200 dark:border-white/[0.06] dark:bg-white/[0.03] dark:hover:border-white/[0.12]"
                                                        }`}
                                                >
                                                    <div
                                                        className={`mb-1 text-[10.5px] font-bold ${active
                                                            ? "text-blue-500"
                                                            : "text-gray-400"
                                                            }`}
                                                    >
                                                        {field === "start"
                                                            ? "شروع"
                                                            : "مهلت انجام"}
                                                    </div>

                                                    <div
                                                        className={`text-[12.5px] font-bold ${active
                                                            ? "text-blue-600 dark:text-blue-400"
                                                            : "text-gray-900 dark:text-white"
                                                            }`}
                                                    >
                                                        {toPersianDigits(f.jd)}{" "}
                                                        {JALALI_MONTHS[
                                                            f.jm - 1
                                                        ]}{" "}
                                                        —{" "}
                                                        {toPersianDigits(
                                                            pad2(f.hour)
                                                        )}
                                                        :
                                                        {toPersianDigits(
                                                            pad2(f.minute)
                                                        )}
                                                    </div>
                                                </button>
                                            );
                                        }
                                    )}
                                </div>

                                <div className="rounded-[1.5rem] border border-gray-100 bg-gray-50/60 p-4 dark:border-white/[0.06] dark:bg-white/[0.03]">
                                    <div className="mb-4 flex items-center justify-between">
                                        <button
                                            type="button"
                                            onClick={prevMonth}
                                            className="flex h-7 w-7 items-center justify-center rounded-xl bg-white text-gray-400 shadow-sm transition-colors hover:text-gray-600 dark:bg-white/[0.05] dark:hover:text-gray-200"
                                        >
                                            <ChevronRight size={15} />
                                        </button>

                                        <div className="flex items-center gap-1.5 text-[13px] font-bold text-gray-900 dark:text-white">
                                            <CalendarDays
                                                size={14}
                                                className="text-gray-400"
                                            />

                                            <span>
                                                {JALALI_MONTHS[viewJm - 1]}
                                            </span>

                                            <span className="text-gray-400">
                                                {toPersianDigits(viewJy)}
                                            </span>
                                        </div>

                                        <button
                                            type="button"
                                            onClick={nextMonth}
                                            className="flex h-7 w-7 items-center justify-center rounded-xl bg-white text-gray-400 shadow-sm transition-colors hover:text-gray-600 dark:bg-white/[0.05] dark:hover:text-gray-200"
                                        >
                                            <ChevronLeft size={15} />
                                        </button>
                                    </div>

                                    <div className="mb-2 grid grid-cols-7 gap-1">
                                        {JALALI_WEEKDAYS.map((w) => (
                                            <div
                                                key={w}
                                                className="py-1 text-center text-[10.5px] font-bold text-gray-300 dark:text-white/25"
                                            >
                                                {w}
                                            </div>
                                        ))}
                                    </div>

                                    <div className="grid grid-cols-7 gap-1">
                                        {cells.map((day, idx) => {
                                            const isSelected =
                                                day !== null &&
                                                current.jy === viewJy &&
                                                current.jm === viewJm &&
                                                current.jd === day;

                                            const isToday =
                                                day !== null &&
                                                ty === viewJy &&
                                                tm === viewJm &&
                                                td === day;

                                            return (
                                                <button
                                                    key={idx}
                                                    type="button"
                                                    disabled={day === null}
                                                    onClick={() =>
                                                        day &&
                                                        setCurrent((p) => ({
                                                            ...p,
                                                            jy: viewJy,
                                                            jm: viewJm,
                                                            jd: day,
                                                        }))
                                                    }
                                                    className={`aspect-square rounded-xl text-[12.5px] font-bold transition-colors ${day === null
                                                        ? "invisible"
                                                        : isSelected
                                                            ? "bg-blue-600 text-white"
                                                            : isToday
                                                                ? "border border-blue-400 bg-blue-50 text-blue-600 dark:border-blue-500/40 dark:bg-blue-500/10 dark:text-blue-300"
                                                                : "text-gray-500 hover:bg-gray-100 dark:text-white/60 dark:hover:bg-white/[0.06] dark:hover:text-white"
                                                        }`}
                                                >
                                                    {day !== null
                                                        ? toPersianDigits(day)
                                                        : ""}
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-3">
                                    <NiceSelect
                                        label="ساعت"
                                        value={current.hour}
                                        onChange={(hour) =>
                                            setCurrent((p) => ({ ...p, hour }))
                                        }
                                        options={hoursOptions}
                                    />
                                    <NiceSelect
                                        label="دقیقه"
                                        value={current.minute}
                                        onChange={(minute) =>
                                            setCurrent((p) => ({ ...p, minute }))
                                        }
                                        options={minutesOptions}
                                    />
                                </div>

                                <AnimatePresence>
                                    {(error || externalError) && (
                                        <m.div
                                            initial={{
                                                opacity: 0,
                                                y: 6,
                                            }}
                                            animate={{
                                                opacity: 1,
                                                y: 0,
                                            }}
                                            exit={{
                                                opacity: 0,
                                                y: 4,
                                            }}
                                            className="rounded-2xl bg-red-50 px-3.5 py-3 text-center text-[11.5px] font-semibold text-red-500 dark:bg-red-500/10 dark:text-red-400"
                                        >
                                            {error || externalError}
                                        </m.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        </div>

                        <div className="flex shrink-0 items-center gap-2 px-8 pb-8 pt-5">
                            <button
                                type="button"
                                onClick={onClose}
                                className="flex h-11 flex-1 items-center justify-center rounded-full border border-gray-100 bg-gray-50 text-[13px] font-bold text-gray-500 transition-colors hover:text-gray-700 dark:border-white/[0.06] dark:bg-white/[0.03] dark:text-white/50 dark:hover:text-white/80"
                            >
                                انصراف
                            </button>

                            <m.button
                                type="button"
                                whileTap={{ scale: 0.97 }}
                                onClick={handleSubmit}
                                disabled={loading}
                                className="relative flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-blue-600 text-[13px] font-bold text-white transition-colors hover:bg-blue-500 disabled:opacity-40"
                            >
                                <BusyContent busy={loading}>
                                    <>
                                            <Check size={14} strokeWidth={3} />
                                            تأیید
                                        </>
                                </BusyContent>
                            </m.button>
                        </div>
                    </m.div>
                </ModalLayer>
            )}
        </AnimatePresence>,
        document.body
    );
}