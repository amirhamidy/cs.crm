"use client";
import { useEffect, useMemo, useState } from "react";
import { BusyContent } from "@/components/ui/Button";
import { AnimatePresence, m, useReducedMotion } from "framer-motion";
import { Backdrop } from "@/components/ui/Backdrop";
import { panelMotion } from "@/lib/motion";
import { Check, Send, UserRound, X } from "lucide-react";
import { useTheme } from "next-themes";
import { useAuthStore } from "@/store/authStore";
import { accountsApi } from "@/lib/api/accounts";
import { createInternalTask } from "./Api";
import type { InternalTask } from "./types";

interface UserListItem {
    id: number;
    username: string;
    type: number;
}

interface EmployeeListItem {
    id: number;
    username: string;
    full_name: string;
}

interface Recipient {
    id: number;
    label: string;
}

interface CreateTicketModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCreated: (task: InternalTask) => void;
    employees?: EmployeeListItem[];
}

export default function CreateTicketModal({
    isOpen,
    onClose,
    onCreated,
    employees: employeesProp,
}: CreateTicketModalProps) {
    const reduced = useReducedMotion() ?? false;
    const { resolvedTheme } = useTheme();
    const isDark = resolvedTheme === "dark";
    const { userId } = useAuthStore();
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [selected, setSelected] = useState<number[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [users, setUsers] = useState<UserListItem[]>([]);
    const [employees, setEmployees] = useState<EmployeeListItem[]>([]);

    useEffect(() => {
        if (isOpen) {
            setTitle("");
            setDescription("");
            setSelected([]);
            setError("");
            setLoading(false);

            const usersRequest = accountsApi.users.all() as Promise<UserListItem[]>;

            const employeesRequest = employeesProp
                ? Promise.resolve(employeesProp)
                : (accountsApi.employees.all() as Promise<EmployeeListItem[]>);

            Promise.all([usersRequest, employeesRequest])
                .then(([userList, empList]) => {
                    setUsers(Array.isArray(userList) ? userList : []);
                    setEmployees(Array.isArray(empList) ? empList : []);
                })
                .catch(() => {
                    setUsers([]);
                    setEmployees([]);
                });
        }
    }, [isOpen, employeesProp]);

    const recipients = useMemo<Recipient[]>(() => {
        const usersByUsername = new Map<string, UserListItem>();

        users.forEach((user) => {
            const username = user.username?.trim().toLowerCase();
            if (username) {
                usersByUsername.set(username, user);
            }
        });

        const employeeUsernames = new Set(
            employees
                .map((emp) => emp.username?.trim().toLowerCase())
                .filter((username): username is string => Boolean(username)),
        );

        const employeeRecipients: Recipient[] = employees
            .map((emp) => {
                const username = emp.username?.trim().toLowerCase() || "";
                const matchedUser = usersByUsername.get(username);

                if (!matchedUser) return null;

                return {
                    id: matchedUser.id,
                    label: emp.full_name || emp.username,
                };
            })
            .filter((recipient): recipient is Recipient => recipient !== null);

        const adminRecipients: Recipient[] = users
            .filter((user) => {
                const username = user.username?.trim().toLowerCase() || "";
                return user.type === 1 && !employeeUsernames.has(username);
            })
            .map((user) => ({
                id: user.id,
                label: user.username,
            }));

        return [...employeeRecipients, ...adminRecipients];
    }, [users, employees]);

    if (!isOpen) return null;

    function toggleUser(id: number) {
        setSelected((prev) =>
            prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
        );
    }

    async function handleSubmit(e: React.FormEvent) {
        e.preventDefault();
        if (!title.trim() || selected.length === 0) {
            setError("عنوان و حداقل یک کاربر را انتخاب کن");
            return;
        }
        if (!userId) {
            setError("اطلاعات کاربری یافت نشد، مجدداً وارد شوید");
            return;
        }
        setLoading(true);
        setError("");
        try {
            const { data } = await createInternalTask({
                title: title.trim(),
                description: description.trim(),
                assigned_to: selected,
                created_by: userId,
            });
            onCreated(data);
            onClose();
        } catch {
            setError("خطا در ایجاد تیکت");
            setLoading(false);
        }
    }

    return (
        <AnimatePresence>
            {isOpen && (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center px-4"
                >
                    <Backdrop onClick={onClose} />
                    <m.div
                        {...panelMotion(false, reduced)}
                        className="relative w-full max-w-[430px] overflow-hidden rounded-3xl border"
                        style={{
                            background: isDark ? "#111827" : "#ffffff",
                            borderColor: isDark ? "rgba(255,255,255,0.07)" : "rgba(0,0,0,0.06)",
                            boxShadow: "0 24px 64px rgba(0,0,0,0.28)",
                        }}
                        dir="rtl"
                    >
                        <div
                            className="flex items-center justify-between border-b px-5 py-4"
                            style={{
                                borderColor: isDark ? "rgba(255,255,255,0.06)" : "rgba(0,0,0,0.06)",
                            }}
                        >
                            <div className="flex items-center gap-3">
                                <div
                                    className="flex h-9 w-9 items-center justify-center rounded-xl"
                                    style={{ background: "rgba(99,102,241,0.10)" }}
                                >
                                    <Send size={15} className="text-indigo-500" />
                                </div>
                                <div>
                                    <h3 className="text-[14px] font-extrabold text-gray-900 dark:text-white">
                                        ایجاد تیکت جدید
                                    </h3>
                                    <p className="mt-0.5 text-[11px] text-gray-400 dark:text-gray-500">
                                        تیکت را برای خود یا همکارانت ارسال کن
                                    </p>
                                </div>
                            </div>
                            <button
                                type="button"
                                onClick={onClose}
                                disabled={loading}
                                className="flex h-8 w-8 items-center justify-center rounded-xl text-gray-400 transition-colors hover:text-gray-600 disabled:opacity-40 dark:hover:text-gray-300"
                                style={{
                                    background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)",
                                }}
                            >
                                <X size={15} />
                            </button>
                        </div>
                        <form onSubmit={handleSubmit} className="max-h-[70vh] space-y-4 overflow-y-auto p-5">
                            <div className="space-y-2">
                                <label className="text-[12px] font-bold text-gray-500 dark:text-gray-400">
                                    عنوان
                                </label>
                                <input
                                    value={title}
                                    onChange={(e) => setTitle(e.target.value)}
                                    placeholder="عنوان تیکت را بنویس..."
                                    className="w-full rounded-2xl border bg-white px-4 py-3 text-sm text-black outline-none transition-all duration-200 focus:border-indigo-500 dark:bg-white/[0.04] dark:border-white/[0.08] dark:text-white dark:focus:border-violet-500"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[12px] font-bold text-gray-500 dark:text-gray-400">
                                    توضیحات
                                </label>
                                <textarea
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    rows={4}
                                    placeholder="توضیحات تیکت را بنویس..."
                                    className="w-full resize-none rounded-2xl border bg-white px-4 py-3 text-sm text-black outline-none transition-all duration-200 focus:border-indigo-500 dark:bg-white/[0.04] dark:border-white/[0.08] dark:text-white dark:focus:border-violet-500"
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[12px] font-bold text-gray-500 dark:text-gray-400">
                                    ارسال به
                                </label>
                                <div className="flex flex-wrap gap-2">
                                    {recipients.map((recipient) => {
                                        const isActive = selected.includes(recipient.id);
                                        const displayName = recipient.label;
                                        return (
                                            <button
                                                key={recipient.id}
                                                type="button"
                                                onClick={() => toggleUser(recipient.id)}
                                                className="flex items-center gap-1.5 rounded-full py-1 pl-3 pr-1 text-[11px] font-bold transition-colors"
                                                style={{
                                                    background: isActive
                                                        ? "rgba(99,102,241,0.14)"
                                                        : isDark
                                                            ? "rgba(255,255,255,0.04)"
                                                            : "rgba(0,0,0,0.03)",
                                                    border: isActive
                                                        ? "1px solid rgba(99,102,241,0.4)"
                                                        : isDark
                                                            ? "1px solid rgba(255,255,255,0.06)"
                                                            : "1px solid rgba(0,0,0,0.06)",
                                                    color: isActive ? "#6366f1" : isDark ? "#9ca3af" : "#6b7280",
                                                }}
                                            >
                                                <span
                                                    className="flex h-5 w-5 items-center justify-center rounded-full text-white"
                                                    style={{
                                                        background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                                                    }}
                                                >
                                                    <UserRound size={11} />
                                                </span>
                                                {displayName}
                                            </button>
                                        );
                                    })}
                                </div>
                            </div>
                            {error && (
                                <p className="text-center text-[11.5px] font-semibold text-red-500 dark:text-red-400">
                                    {error}
                                </p>
                            )}
                            <div className="flex gap-2 pt-1">
                                <button
                                    type="button"
                                    onClick={onClose}
                                    disabled={loading}
                                    className="flex-1 rounded-xl py-2.5 text-[12.5px] font-bold transition-colors disabled:opacity-40"
                                    style={{
                                        background: isDark ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)",
                                        color: isDark ? "#9ca3af" : "#6b7280",
                                    }}
                                >
                                    انصراف
                                </button>
                                <button
                                    type="submit"
                                    disabled={loading}
                                    className="relative flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-[12.5px] font-bold text-white transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
                                    style={{
                                        background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                                        boxShadow: "0 4px 14px rgba(99,102,241,0.3)",
                                    }}
                                >
                                    <BusyContent busy={loading}>
                                            <Check size={13} />
                                            ارسال تیکت
                                        </BusyContent>
                                </button>
                            </div>
                        </form>
                    </m.div>
                </div>
            )}
        </AnimatePresence>
    );
}