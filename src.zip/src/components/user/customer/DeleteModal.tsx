"use client";

import { m, AnimatePresence, useReducedMotion } from "framer-motion";
import { Backdrop } from "@/components/ui/Backdrop";
import { panelMotion } from "@/lib/motion";
import { BusyContent } from "@/components/ui/Button";
import { useTheme } from "next-themes";
import { Trash2 } from "lucide-react";

interface Props {
    customerName: string;
    isOpen: boolean;
    isDeleting: boolean;
    onConfirm: () => void;
    onClose: () => void;
}

export default function CustomerDeleteModal({
    customerName,
    isOpen,
    isDeleting,
    onConfirm,
    onClose,
}: Props) {
    const { resolvedTheme } = useTheme();
    const isDark = resolvedTheme === "dark";
    const reduced = useReducedMotion() ?? false;

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
                    <Backdrop onClick={() => !isDeleting && onClose()} />
                    <m.div
                        {...panelMotion(false, reduced)}
                        className={`relative z-10 w-full max-w-sm rounded-2xl p-6 shadow-2xl ${isDark ? "bg-[#13151f]" : "bg-white"
                            }`}
                    >
                        <div className="flex flex-col items-center text-center gap-4">
                            <div className="w-14 h-14 rounded-2xl bg-red-500/15 flex items-center justify-center">
                                <Trash2 className="w-7 h-7 text-red-400" />
                            </div>
                            <div>
                                <p className={`text-sm font-bold ${isDark ? "text-white" : "text-gray-900"}`}>
                                    حذف مشتری
                                </p>
                                <p className={`text-xs mt-1 ${isDark ? "text-white/50" : "text-gray-500"}`}>
                                    مشتری «{customerName}» حذف بشه؟ این عملیات برگشت‌پذیر نیست.
                                </p>
                            </div>
                            <div className="flex gap-3 w-full">
                                <m.button
                                    whileTap={{ scale: 0.96 }}
                                    onClick={onClose}
                                    disabled={isDeleting}
                                    className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-colors ${isDark
                                            ? "bg-white/8 hover:bg-white/12 text-white/70"
                                            : "bg-gray-100 hover:bg-gray-200 text-gray-600"
                                        }`}
                                >
                                    انصراف
                                </m.button>
                                <m.button
                                    whileTap={{ scale: 0.96 }}
                                    onClick={onConfirm}
                                    disabled={isDeleting}
                                    className="relative flex-1 py-2.5 rounded-xl text-sm font-semibold bg-red-500 hover:bg-red-600 text-white transition-colors disabled:opacity-60"
                                >
                                    <BusyContent busy={isDeleting}>بله، حذف شود</BusyContent>
                                </m.button>
                            </div>
                        </div>
                    </m.div>
                </div>
            )}
        </AnimatePresence>
    );
}
