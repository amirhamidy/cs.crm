"use client";

import { useState } from "react";
import { AnimatePresence, m, useReducedMotion } from "framer-motion";
import { Backdrop } from "@/components/ui/Backdrop";
import { panelMotion } from "@/lib/motion";
import { useVisibleInterval } from "@/hooks/useVisibility";
import { Building2, CalendarClock, ClipboardX, Clock, FolderKanban, MessageSquareText, Paperclip, Pencil, Trash2, UserRound, X } from "lucide-react";
import { useTheme } from "next-themes";
import type { Task, TaskStatus, TaskEmployeeRef } from "@/types/task";
import type { Employee } from "@/types/employee";
import { useEmployeeInfo } from "@/hooks/useEmployeeInfo";
import AdminTaskNotesModal from "./TaskNotesModal";
import TimeRangeModal from "@/components/tasks/TimeRangeModal";
import TaskDeadlineModal, { fetchStepDeadline, type StepDeadline } from "@/components/tasks/TaskDeadlineModal";
import api from "@/lib/axiosInstance";

import { BusyContent } from "@/components/ui/Button";
const AVATAR_GRADIENTS = [
    ["#6366f1", "#8b5cf6"],
    ["#3b82f6", "#6366f1"],
    ["#8b5cf6", "#ec4899"],
    ["#06b6d4", "#6366f1"],
    ["#f59e0b", "#ef4444"],
    ["#10b981", "#3b82f6"],
    ["#f472b6", "#ec4899"],
    ["#8b5cf6", "#f59e0b"],
    ["#3b82f6", "#06b6d4"],
    ["#ef4444", "#f59e0b"],
];

const STATUS_CONFIG: Record<TaskStatus, { label: string; className: string }> = {
    sold: { label: "فروش", className: "border-emerald-500/20 bg-emerald-500/10 text-emerald-400" },
    completed: { label: "انجام شده", className: "border-blue-500/20 bg-blue-500/10 text-blue-400" },
    in_progress: { label: "در حال انجام", className: "border-amber-500/20 bg-amber-500/10 text-amber-400" },
    cancelled: { label: "لغو", className: "border-red-500/20 bg-red-500/10 text-red-400" },
};

type DeadlineUrgency = "overdue" | "critical" | "soon" | "normal" | null;

function getDeadlineUrgency(deadline: string | null | undefined): DeadlineUrgency {
    if (!deadline) return null;
    const diff = new Date(deadline).getTime() - Date.now();
    const hours = diff / (1000 * 60 * 60);
    if (diff < 0) return "overdue";
    if (hours <= 6) return "critical";
    if (hours <= 24) return "soon";
    return "normal";
}

const URGENCY_ACCENT: Record<Exclude<DeadlineUrgency, null | "normal">, string> = {
    overdue: "#ef4444",
    critical: "#f97316",
    soon: "#eab308",
};

const URGENCY_LABEL: Record<Exclude<DeadlineUrgency, null | "normal">, string> = {
    overdue: "منقضی شده",
    critical: "فوری",
    soon: "امروز",
};

interface TaskWithStep extends Omit<Task, "assigned_employee"> {
    current_step?: number | { id: number } | string | null;
    assigned_employee?: TaskEmployeeRef | TaskEmployeeRef[] | number | number[] | null;
}

function getGradient(id: number) {
    return AVATAR_GRADIENTS[Math.abs(id) % AVATAR_GRADIENTS.length];
}

function extractId(value: unknown): number | null {
    if (value === null || value === undefined) return null;
    if (typeof value === "number") return value;
    if (typeof value === "string") {
        const n = Number(value);
        return Number.isFinite(n) ? n : null;
    }
    if (
        typeof value === "object" &&
        !Array.isArray(value) &&
        "id" in (value as Record<string, unknown>)
    ) {
        const id = (value as { id?: unknown }).id;
        return typeof id === "number"
            ? id
            : Number.isFinite(Number(id))
                ? Number(id)
                : null;
    }
    return null;
}

function extractEmployeeIds(value: TaskWithStep["assigned_employee"]): number[] {
    if (value === null || value === undefined) return [];
    const arr = Array.isArray(value) ? value : [value];
    return arr.map((item) => extractId(item)).filter((id): id is number => id !== null);
}

function extractDepartmentName(value: unknown): string | null {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const dep = value as { name?: string };
    return dep.name ?? null;
}

function toTask(task: TaskWithStep): Task {
    const emp = task.assigned_employee;
    const assignedEmployee = Array.isArray(emp) ? (emp[0] ?? null) : (emp ?? null);
    return {
        ...task,
        assigned_employee: assignedEmployee as Task["assigned_employee"],
    } as Task;
}

function Chip({ isDark, children }: { isDark: boolean; children: React.ReactNode }) {
    return (
        <div
            className="flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-bold"
            style={{
                border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.06)",
                background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)",
                color: isDark ? "#9ca3af" : "#6b7280",
            }}
        >
            {children}
        </div>
    );
}

function EmployeeChip({ id, isDark }: { id: number; isDark: boolean }) {
    const { data, loading } = useEmployeeInfo(id);
    const gradient = getGradient(id);
    const name = loading ? "..." : (data?.full_name ?? data?.username ?? `کارمند ${id}`);

    return (
        <div
            className="flex items-center gap-1.5 rounded-full py-0.5 pl-2 pr-0.5"
            style={{
                border: isDark ? "1px solid rgba(255,255,255,0.06)" : "1px solid rgba(0,0,0,0.06)",
                background: isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.03)",
            }}
        >
            <span
                className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full text-[9px] font-extrabold text-white"
                style={{ background: `linear-gradient(135deg, ${gradient[0]}, ${gradient[1]})` }}
            >
                <UserRound size={11} />
            </span>
            <span
                className="text-[10.5px] font-bold"
                style={{ color: isDark ? "#d1d5db" : "#4b5563" }}
            >
                {name}
            </span>
        </div>
    );
}

interface TaskCardProps {
    task: TaskWithStep;
    index?: number;
    employees?: Employee[];
    onEdit: (task: Task) => void;
    onDelete: (taskId: number) => Promise<boolean | void> | void;
    onUpdated?: (task: Task) => void;
    canManageDeadline?: boolean;
}

export default function TaskCard({
    task,
    index = 0,
    employees,
    onEdit,
    onDelete,
    onUpdated,
    canManageDeadline = true,
}: TaskCardProps) {
    const reduced = useReducedMotion() ?? false;
    const { resolvedTheme } = useTheme();
    const isDark = resolvedTheme === "dark";

    const [hovered, setHovered] = useState(false);
    const [timeModalOpen, setTimeModalOpen] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [deleteError, setDeleteError] = useState<string | null>(null);
    const [savingTime, setSavingTime] = useState(false);
    const [notesModalOpen, setNotesModalOpen] = useState(false);
    const [timeError, setTimeError] = useState<string | null>(null);
    const [stepDeadline, setStepDeadline] = useState<StepDeadline | null>(null);
    const [deadlineModalOpen, setDeadlineModalOpen] = useState(false);
    const [, forceTick] = useState(0);

    const employeeIds = extractEmployeeIds(task.assigned_employee);
    const departmentName = extractDepartmentName(task.department);
    const caseTitle =
        task.case && typeof task.case === "object" && "title" in task.case
            ? (task.case as { title?: string }).title
            : null;

    const stepId = extractId(task.current_step);
    const status = (task.status ?? "cancelled") as TaskStatus;
    const statusConfig = STATUS_CONFIG[status] ?? {
        label: "نامشخص",
        className: "border-gray-500/20 bg-gray-500/10 text-gray-400",
    };

    const isActiveTask =
        status !== "completed" && status !== "cancelled" && status !== "sold";
    const urgency = isActiveTask ? getDeadlineUrgency(stepDeadline?.deadline) : null;
    const accent =
        urgency && urgency !== "normal" ? URGENCY_ACCENT[urgency] : null;

    
    const openTimeModal = () => {
        setTimeModalOpen(true);
        if (stepId && !stepDeadline) {
            fetchStepDeadline(task.id, stepId).then(setStepDeadline).catch(() => undefined);
        }
    };

    
    useVisibleInterval(
        () => forceTick((t) => t + 1),
        60000,
        Boolean(stepDeadline?.deadline) && isActiveTask,
    );

    async function handleDelete() {
        setDeleting(true);
        setDeleteError(null);
        try {
            await onDelete(task.id);
            setShowConfirm(false);
        } catch {
            setDeleteError("خطا در حذف تسک. دوباره تلاش کن.");
        } finally {
            setDeleting(false);
        }
    }

    async function handleTimeSubmit(startedAt: string, deadline: string) {
        if (!stepId) {
            setTimeError("مرحله فعلی این تسک مشخص نیست");
            return;
        }
        setSavingTime(true);
        setTimeError(null);
        try {
            const { data } = await api.patch(
                `/tasks/api/v1/tasks/${task.id}/steps/${stepId}/deadline/patch/`,
                { started_at: startedAt, deadline }
            );
            setStepDeadline({
                started_at: data?.started_at ?? startedAt,
                deadline: data?.deadline ?? deadline,
            });
            onUpdated?.(data);
            setTimeModalOpen(false);
        } catch {
            setTimeError("خطا در ثبت بازه زمانی");
        } finally {
            setSavingTime(false);
        }
    }

    function handleCloseConfirm() {
        if (deleting) return;
        setShowConfirm(false);
        setDeleteError(null);
    }

    return (
        <>
            <m.div
                onHoverStart={() => setHovered(true)}
                onHoverEnd={() => setHovered(false)}
                className="relative flex flex-col gap-3 overflow-hidden rounded-2xl p-4"
                style={{
                    border: accent
                        ? `1px solid color-mix(in srgb, ${accent} 40%, transparent)`
                        : isDark
                            ? "1px solid rgba(255,255,255,0.06)"
                            : "1px solid rgba(0,0,0,0.06)",
                    background: accent
                        ? `color-mix(in srgb, ${accent} ${urgency === "overdue" ? 7 : urgency === "critical" ? 5 : 4
                        }%, ${isDark ? "#111827" : "#fafafa"})`
                        : isDark
                            ? "rgba(255,255,255,0.02)"
                            : "#fafafa",
                    minHeight: "130px",
                    opacity: deleting ? 0.45 : 1,
                    pointerEvents: deleting ? "none" : undefined,
                    boxShadow: accent
                        ? `0 0 0 1px color-mix(in srgb, ${accent} 15%, transparent), 0 4px 24px color-mix(in srgb, ${accent} 12%, transparent)`
                        : isDark
                            ? "0 2px 24px rgba(0,0,0,0.2)"
                            : "0 2px 16px rgba(0,0,0,0.04)",
                    transition:
                        "border-color 0.4s ease, background 0.4s ease, box-shadow 0.4s ease",
                }}
            >
                {urgency === "overdue" && (
                    <m.div
                        className="pointer-events-none absolute inset-x-0 top-0 h-[2px]"
                        style={{
                            background: `linear-gradient(90deg, transparent, ${accent}, transparent)`,
                        }}
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                    />
                )}

                <svg
                    className="pointer-events-none absolute inset-0 h-full w-full"
                    style={{ borderRadius: "1rem" }}
                >
                    <defs>
                        <linearGradient
                            id={`taskCardBorderGrad-${task.id}`}
                            x1="100%"
                            y1="100%"
                            x2="0%"
                            y2="0%"
                        >
                            <stop offset="0%" stopColor="#6366f1" />
                            <stop offset="100%" stopColor="#8b5cf6" />
                        </linearGradient>
                    </defs>
                    <m.rect
                        x="1"
                        y="1"
                        width="calc(100% - 2px)"
                        height="calc(100% - 2px)"
                        rx="15"
                        ry="15"
                        fill="none"
                        stroke={`url(#taskCardBorderGrad-${task.id})`}
                        strokeWidth="1.5"
                        pathLength="1"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={
                            hovered
                                ? { pathLength: 1, opacity: 1 }
                                : { pathLength: 0, opacity: 0 }
                        }
                        transition={{ duration: 0.55, ease: "easeInOut" }}
                    />
                </svg>

                <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                        <span
                            className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[10.5px] font-bold ${statusConfig.className}`}
                        >
                            <span
                                className={`h-1.5 w-1.5 rounded-full bg-current ${status === "in_progress" ? "animate-pulse" : ""
                                    }`}
                            />
                            {statusConfig.label}
                        </span>
                        {accent && (
                            <span
                                className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold"
                                style={{
                                    color: accent,
                                    background: `color-mix(in srgb, ${accent} 12%, transparent)`,
                                    border: `1px solid color-mix(in srgb, ${accent} 30%, transparent)`,
                                }}
                            >
                                <m.span
                                    className="h-1.5 w-1.5 rounded-full"
                                    style={{ background: accent }}
                                    animate={
                                        urgency !== "soon"
                                            ? { opacity: [1, 0.3, 1] }
                                            : undefined
                                    }
                                    transition={{
                                        duration: 1.6,
                                        repeat: Infinity,
                                        ease: "easeInOut",
                                    }}
                                />
                                {URGENCY_LABEL[urgency as Exclude<DeadlineUrgency, null | "normal">]}
                            </span>
                        )}
                    </div>

                    <div className="flex items-center gap-1.5">
                        <button
                            type="button"
                            onClick={() => setNotesModalOpen(true)}
                            className="flex h-8 w-8 items-center justify-center rounded-xl transition-colors"
                            style={{
                                background: isDark
                                    ? "rgba(255,255,255,0.05)"
                                    : "rgba(0,0,0,0.04)",
                            }}
                            title="یادداشت‌ها"
                        >
                            <MessageSquareText size={14} className="text-indigo-400" />
                        </button>
                        <button
                            type="button"
                            onClick={() => setDeadlineModalOpen(true)}
                            className="flex h-7 w-7 items-center justify-center rounded-xl transition-colors"
                            style={{
                                background: isDark
                                    ? "rgba(99,102,241,0.1)"
                                    : "rgba(99,102,241,0.07)",
                                color: isDark ? "#a5b4fc" : "#6366f1",
                            }}
                            title="مشاهده ددلاین"
                        >
                            <CalendarClock size={11} />
                        </button>
                        {canManageDeadline && (
                            <button
                                type="button"
                                onClick={openTimeModal}
                                className="flex h-7 w-7 items-center justify-center rounded-xl transition-colors"
                                style={{
                                    background: isDark
                                        ? "rgba(99,102,241,0.1)"
                                        : "rgba(99,102,241,0.07)",
                                    color: isDark ? "#a5b4fc" : "#6366f1",
                                }}
                                title="تعیین بازه زمانی"
                            >
                                <Clock size={11} />
                            </button>
                        )}
                        <button
                            type="button"
                            onClick={() => onEdit(toTask(task))}
                            className="flex h-7 w-7 items-center justify-center rounded-xl transition-colors"
                            style={{
                                background: isDark
                                    ? "rgba(99,102,241,0.1)"
                                    : "rgba(99,102,241,0.07)",
                                color: isDark ? "#a5b4fc" : "#6366f1",
                            }}
                            title="ویرایش تسک"
                        >
                            <Pencil size={11} />
                        </button>
                        <button
                            type="button"
                            onClick={() => setShowConfirm(true)}
                            disabled={deleting}
                            className="relative flex h-7 w-7 items-center justify-center rounded-xl transition-colors disabled:opacity-40"
                            style={{
                                background: isDark
                                    ? "rgba(239,68,68,0.1)"
                                    : "rgba(239,68,68,0.07)",
                                color: "#ef4444",
                            }}
                            title="حذف تسک"
                        >
                            <BusyContent busy={deleting}>
                                <Trash2 size={11} />
                            </BusyContent>
                        </button>
                    </div>
                </div>

                <div className="flex flex-col gap-1">
                    <h3
                        className="text-[13.5px] font-extrabold leading-tight"
                        style={{ color: isDark ? "#f3f4f6" : "#1f2937" }}
                    >
                        {task.title}
                    </h3>
                    {task.description ? (
                        <p
                            className="line-clamp-2 text-[12px] leading-6"
                            style={{ color: isDark ? "#9ca3af" : "#6b7280" }}
                        >
                            {task.description}
                        </p>
                    ) : null}
                </div>

                <div
                    className="mt-auto flex flex-wrap items-center gap-2 border-t pt-2.5"
                    style={{
                        borderColor: isDark
                            ? "rgba(255,255,255,0.05)"
                            : "rgba(0,0,0,0.05)",
                    }}
                >
                    {employeeIds.length > 0 ? (
                        employeeIds.map((id) => (
                            <EmployeeChip key={id} id={id} isDark={isDark} />
                        ))
                    ) : (
                        <div
                            className="flex items-center gap-1.5 rounded-full py-0.5 pl-2 pr-0.5"
                            style={{
                                border: isDark
                                    ? "1px solid rgba(255,255,255,0.06)"
                                    : "1px solid rgba(0,0,0,0.06)",
                                background: isDark
                                    ? "rgba(255,255,255,0.04)"
                                    : "rgba(0,0,0,0.03)",
                            }}
                        >
                            <span
                                className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full text-[9px] font-extrabold text-white"
                                style={{
                                    background: `linear-gradient(135deg, #6366f1, #8b5cf6)`,
                                }}
                            >
                                <UserRound size={11} />
                            </span>
                            <span
                                className="text-[10.5px] font-bold"
                                style={{ color: isDark ? "#d1d5db" : "#4b5563" }}
                            >
                                بدون مسئول
                            </span>
                        </div>
                    )}

                    {departmentName ? (
                        <Chip isDark={isDark}>
                            <Building2 size={11} />
                            {departmentName}
                        </Chip>
                    ) : null}

                    {caseTitle ? (
                        <Chip isDark={isDark}>
                            <FolderKanban size={11} />
                            {caseTitle}
                        </Chip>
                    ) : null}

                    {task.files && task.files.length > 0 ? (
                        <Chip isDark={isDark}>
                            <Paperclip size={11} />
                            {task.files.length}
                        </Chip>
                    ) : null}
                </div>
            </m.div>

            <AnimatePresence>
                {showConfirm && (
                    <div
                        className="fixed inset-0 z-50 flex items-center justify-center px-4"
                    >
                        <Backdrop onClick={handleCloseConfirm} />
                        <m.div
                            {...panelMotion(false, reduced)}
                            dir="rtl"
                            className="relative flex w-full max-w-md flex-col overflow-hidden rounded-[2rem] border border-gray-100 bg-white shadow-sm dark:border-white/[0.06] dark:bg-[#111827]"
                        >
                            <div className="flex shrink-0 items-center justify-between px-8 pb-6 pt-8">
                                <div className="flex items-center gap-2.5">
                                    <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-red-50 dark:bg-red-500/10">
                                        <Trash2 size={15} className="text-red-500" />
                                    </div>
                                    <div>
                                        <h3 className="text-[14px] font-extrabold text-gray-900 dark:text-white">حذف وظیفه</h3>
                                        <p className="mt-0.5 text-[11px] text-gray-400">این عملیات قابل بازگشت نیست</p>
                                    </div>
                                </div>
                                <button
                                    type="button"
                                    onClick={handleCloseConfirm}
                                    disabled={deleting}
                                    className="flex h-8 w-8 items-center justify-center rounded-xl bg-gray-100 text-gray-400 transition-colors hover:text-gray-600 disabled:opacity-40 dark:bg-white/[0.05] dark:hover:text-gray-300"
                                >
                                    <X size={15} />
                                </button>
                            </div>

                            <div className="flex-1 px-8 pb-2">
                                <p className="text-[12.5px] font-semibold leading-6 text-gray-500 dark:text-gray-400">
                                    تسک{" "}
                                    <span className="font-extrabold text-gray-900 dark:text-white">{task.title}</span>{" "}
                                    برای همیشه حذف خواهد شد.
                                </p>

                                <AnimatePresence>
                                    {deleteError && (
                                        <m.div
                                            initial={{ opacity: 0, y: 6 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, y: 4 }}
                                            className="mt-4 flex items-start gap-2.5 rounded-2xl bg-red-50 px-3.5 py-3 dark:bg-red-500/10"
                                        >
                                            <ClipboardX size={14} className="mt-0.5 shrink-0 text-red-500" />
                                            <p className="flex-1 text-[11.5px] font-semibold leading-5 text-red-500 dark:text-red-400">
                                                {deleteError}
                                            </p>
                                        </m.div>
                                    )}
                                </AnimatePresence>
                            </div>

                            <div className="flex shrink-0 items-center gap-2 px-8 pb-8 pt-5">
                                <button
                                    type="button"
                                    onClick={handleCloseConfirm}
                                    disabled={deleting}
                                    className="flex h-11 flex-1 items-center justify-center rounded-full bg-gray-100 text-[13px] font-bold text-gray-600 transition-colors hover:bg-gray-200 disabled:opacity-40 dark:bg-white/[0.05] dark:text-gray-300 dark:hover:bg-white/[0.08]"
                                >
                                    انصراف
                                </button>
                                <button
                                    type="button"
                                    onClick={handleDelete}
                                    disabled={deleting}
                                    className="relative flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-red-600 text-[13px] font-bold text-white transition-colors hover:bg-red-500 disabled:opacity-40"
                                >
                                    <BusyContent busy={deleting}>
                                        <>
                                                <Trash2 size={13} strokeWidth={2.5} />
                                                حذف کن
                                            </>
                                    </BusyContent>
                                </button>
                            </div>
                        </m.div>
                    </div>
                )}
            </AnimatePresence>

            <TaskDeadlineModal
                open={deadlineModalOpen}
                onClose={() => setDeadlineModalOpen(false)}
                taskId={task.id}
                taskTitle={task.title}
                stepId={stepId}
                onLoaded={setStepDeadline}
            />

            <AnimatePresence>
                {notesModalOpen && (
                    <AdminTaskNotesModal
                        isOpen={notesModalOpen}
                        taskId={task.id}
                        taskTitle={task.title}
                        onClose={() => setNotesModalOpen(false)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {timeModalOpen && (
                    <TimeRangeModal
                        open={timeModalOpen}
                        initialStartedAt={stepDeadline?.started_at}
                        initialDeadline={stepDeadline?.deadline}
                        loading={savingTime}
                        error={timeError}
                        onClose={() => {
                            setTimeModalOpen(false);
                            setTimeError(null);
                        }}
                        onSubmit={handleTimeSubmit}
                    />
                )}
            </AnimatePresence>
        </>
    );
}
