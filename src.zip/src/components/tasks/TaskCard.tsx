"use client";

import { useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, m } from "framer-motion";
import { useVisibleInterval } from "@/hooks/useVisibility";
import { Building2, CalendarClock, ClipboardX, Clock, FolderKanban, Paperclip, Pencil, Trash2, UserRound, X, MessageSquareText } from "lucide-react";
import { useTheme } from "next-themes";
import type { Task, TaskStatus, TaskEmployeeRef } from "@/types/task";
import AdminTaskNotesModal from "./AdminTaskNotesModal";
import TimeRangeModal from "./TimeRangeModal";
import TaskDeadlineModal, { fetchStepDeadline, type StepDeadline } from "./TaskDeadlineModal";
import api from "@/lib/axiosInstance";
import { useEmployeeInfo } from "@/hooks/useEmployeeInfo";
import type { Employee } from "@/types/employee";

import { BusyContent } from "@/components/ui/Button";
const AVATAR_GRADIENTS = [
    ["#6366f1", "#8b5cf6"], ["#3b82f6", "#6366f1"],
    ["#8b5cf6", "#ec4899"], ["#06b6d4", "#6366f1"],
    ["#f59e0b", "#ef4444"], ["#10b981", "#3b82f6"],
    ["#f472b6", "#ec4899"], ["#8b5cf6", "#f59e0b"],
    ["#3b82f6", "#06b6d4"], ["#ef4444", "#f59e0b"],
];

const STATUS_CONFIG: Record<TaskStatus, { label: string; className: string }> = {
    sold: { label: "فروش", className: "border-emerald-500/20 bg-emerald-500/10 text-emerald-400" },
    completed: { label: "انجام شده", className: "border-blue-500/20 bg-blue-500/10 text-blue-400" },
    in_progress: { label: "در حال انجام", className: "border-amber-500/20 bg-amber-500/10 text-amber-400" },
    cancelled: { label: "لغو", className: "border-red-500/20 bg-red-500/10 text-red-400" },
};

type DeadlineUrgency = "overdue" | "critical" | "soon" | "normal" | null;
type ActiveUrgency = "overdue" | "critical" | "soon";

function getDeadlineUrgency(deadline?: string | null): DeadlineUrgency {
    if (!deadline) return null;
    const diff = new Date(deadline).getTime() - Date.now();
    const hours = diff / 3600000;
    if (diff < 0) return "overdue";
    if (hours <= 6) return "critical";
    if (hours <= 24) return "soon";
    return "normal";
}

const URGENCY_ACCENT: Record<ActiveUrgency, string> = {
    overdue: "#ef4444",
    critical: "#f97316",
    soon: "#eab308",
};

const URGENCY_LABEL: Record<ActiveUrgency, string> = {
    overdue: "منقضی شده",
    critical: "فوری",
    soon: "امروز",
};

function isActiveUrgency(u: DeadlineUrgency): u is ActiveUrgency {
    return u === "overdue" || u === "critical" || u === "soon";
}

interface TaskWithStep extends Omit<Task, "assigned_employee"> {
    current_step?: number | { id: number } | string | null;
    assigned_employee?: TaskEmployeeRef | TaskEmployeeRef[] | number | number[] | null;
}

function getGradient(id: number) {
    return AVATAR_GRADIENTS[Math.abs(id) % AVATAR_GRADIENTS.length];
}

function extractId(value: unknown): number | null {
    if (typeof value === "number") return value;
    if (typeof value === "string" && Number.isFinite(Number(value))) return Number(value);
    if (value && typeof value === "object" && !Array.isArray(value) && "id" in value) {
        const id = (value as { id?: unknown }).id;
        return Number.isFinite(Number(id)) ? Number(id) : null;
    }
    return null;
}

function extractEmployeeIds(value: TaskWithStep["assigned_employee"]) {
    if (value == null) return [];
    return (Array.isArray(value) ? value : [value])
        .map(extractId)
        .filter((id): id is number => id !== null);
}

function extractDepartmentName(value: unknown) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    return (value as { name?: string }).name ?? null;
}

function toTask(task: TaskWithStep): Task {
    const employee = Array.isArray(task.assigned_employee)
        ? task.assigned_employee[0] ?? null
        : task.assigned_employee ?? null;
    return { ...task, assigned_employee: employee as Task["assigned_employee"] } as Task;
}

function Chip({ isDark, children }: { isDark: boolean; children: React.ReactNode }) {
    return (
        <div
            className="flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10.5px] font-bold"
            style={{
                border: `1px solid ${isDark ? "rgba(255,255,255,.06)" : "rgba(0,0,0,.06)"}`,
                background: isDark ? "rgba(255,255,255,.04)" : "rgba(0,0,0,.03)",
                color: isDark ? "#9ca3af" : "#6b7280",
            }}
        >
            {children}
        </div>
    );
}

function EmployeeChip({ id, isDark }: { id: number; isDark: boolean }) {
    const { data, loading } = useEmployeeInfo(id);
    const gradient = getGradient(id);

    return (
        <div
            className="flex items-center gap-1.5 rounded-full py-0.5 pl-2 pr-0.5"
            style={{
                border: `1px solid ${isDark ? "rgba(255,255,255,.06)" : "rgba(0,0,0,.06)"}`,
                background: isDark ? "rgba(255,255,255,.04)" : "rgba(0,0,0,.03)",
            }}
        >
            <span
                className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white"
                style={{ background: `linear-gradient(135deg,${gradient[0]},${gradient[1]})` }}
            >
                <UserRound size={11} />
            </span>
            <span className="text-[10.5px] font-bold" style={{ color: isDark ? "#d1d5db" : "#4b5563" }}>
                {loading ? "..." : data?.full_name ?? data?.username ?? `کارمند ${id}`}
            </span>
        </div>
    );
}

interface TaskCardProps {
    task: TaskWithStep;
    deleting?: boolean;
    index?: number;
    readOnly?: boolean;
    onEdit?: (task: Task) => void;
    onUpdated?: (task: Task) => void;
    onDelete?: (taskId: number) => Promise<boolean> | void | Promise<void>;
    employees?: Employee[];
    onReorder?: (dragIndex: number, hoverIndex: number) => void;
    canManageDeadline?: boolean;
}

export default function TaskCard({
    task,
    index = 0,
    readOnly = false,
    onEdit,
    onDelete,
    onUpdated,
}: TaskCardProps) {
    const { resolvedTheme } = useTheme();
    const isDark = resolvedTheme === "dark";
    const [hovered, setHovered] = useState(false);
    const [timeModalOpen, setTimeModalOpen] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [deleteError, setDeleteError] = useState<string | null>(null);
    const [savingTime, setSavingTime] = useState(false);
    const [notesModalOpen, setNotesModalOpen] = useState(false);
    const [timeError, setTimeError] = useState<string | null>(null);
    const [stepDeadline, setStepDeadline] = useState<StepDeadline | null>(null);
    const [deadlineModalOpen, setDeadlineModalOpen] = useState(false);
    const [, forceTick] = useState(0);

    const employeeIds = extractEmployeeIds(task.assigned_employee);
    const departmentName = extractDepartmentName(task.department);
    const caseTitle =
        task.case && typeof task.case === "object" && "title" in task.case
            ? (task.case as { title?: string }).title
            : null;

    const stepId = extractId(task.current_step);
    const status = (task.status ?? "cancelled") as TaskStatus;
    const statusConfig = STATUS_CONFIG[status] ?? {
        label: "نامشخص",
        className: "border-gray-500/20 bg-gray-500/10 text-gray-400",
    };

    const isActiveTask = !["completed", "cancelled", "sold"].includes(status);
    const urgency = isActiveTask ? getDeadlineUrgency(stepDeadline?.deadline) : null;
    const activeUrgency = isActiveUrgency(urgency) ? urgency : null;
    const accent = activeUrgency ? URGENCY_ACCENT[activeUrgency] : null;

    
    const openTimeModal = () => {
        setTimeModalOpen(true);
        if (stepId && !stepDeadline) {
            fetchStepDeadline(task.id, stepId).then(setStepDeadline).catch(() => undefined);
        }
    };

    
    useVisibleInterval(
        () => forceTick((v) => v + 1),
        60000,
        Boolean(stepDeadline?.deadline) && isActiveTask,
    );

    async function handleDelete() {
        if (!onDelete) return;
        setDeleting(true);
        setDeleteError(null);
        try {
            await onDelete(task.id);
            setShowConfirm(false);
        } catch {
            setDeleteError("خطا در حذف تسک. دوباره تلاش کن.");
        } finally {
            setDeleting(false);
        }
    }

    async function handleTimeSubmit(startedAt: string, deadline: string) {
        if (!stepId) return setTimeError("مرحله فعلی این وظیفه مشخص نیست");

        setSavingTime(true);
        setTimeError(null);

        try {
            const { data } = await api.patch(
                `/tasks/api/v1/tasks/${task.id}/steps/${stepId}/deadline/patch/`,
                { started_at: startedAt, deadline }
            );
            setStepDeadline({
                started_at: data?.started_at ?? startedAt,
                deadline: data?.deadline ?? deadline,
            });
            onUpdated?.(data);
            setTimeModalOpen(false);
        } catch {
            setTimeError("خطا در ثبت بازه زمانی");
        } finally {
            setSavingTime(false);
        }
    }

    function closeConfirm() {
        if (deleting) return;
        setShowConfirm(false);
        setDeleteError(null);
    }

    return (
        <>
            <m.div
                onHoverStart={() => setHovered(true)}
                onHoverEnd={() => setHovered(false)}
                className="relative flex min-h-[130px] flex-col gap-3 overflow-hidden rounded-2xl p-4"
                style={{
                    border: accent ? `1px solid color-mix(in srgb,${accent} 40%,transparent)` : `1px solid ${isDark ? "rgba(255,255,255,.06)" : "rgba(0,0,0,.06)"}`,
                    background: accent
                        ? `color-mix(in srgb,${accent} ${activeUrgency === "overdue" ? 7 : activeUrgency === "critical" ? 5 : 4}%,${isDark ? "#111827" : "#fafafa"})`
                        : isDark ? "rgba(255,255,255,.02)" : "#fafafa",
                    opacity: deleting ? 0.45 : 1,
                    boxShadow: accent ? `0 0 0 1px color-mix(in srgb,${accent} 15%,transparent),0 4px 24px color-mix(in srgb,${accent} 12%,transparent)` : isDark ? "0 2px 24px rgba(0,0,0,.2)" : "0 2px 16px rgba(0,0,0,.04)",
                }}
            >
                {activeUrgency === "overdue" && (
                    <m.div
                        className="pointer-events-none absolute inset-x-0 top-0 h-[2px]"
                        style={{ background: `linear-gradient(90deg,transparent,${accent},transparent)` }}
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 2.2, repeat: Infinity }}
                    />
                )}

                <svg className="pointer-events-none absolute inset-0 h-full w-full">
                    <defs>
                        <linearGradient id={`border-${task.id}`}>
                            <stop offset="0%" stopColor="#6366f1" />
                            <stop offset="100%" stopColor="#8b5cf6" />
                        </linearGradient>
                    </defs>
                    <m.rect
                        x="1" y="1"
                        width="calc(100% - 2px)"
                        height="calc(100% - 2px)"
                        rx="15"
                        fill="none"
                        stroke={`url(#border-${task.id})`}
                        strokeWidth="1.5"
                        pathLength="1"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={hovered ? { pathLength: 1, opacity: 1 } : { pathLength: 0, opacity: 0 }}
                        transition={{ duration: 0.55 }}
                    />
                </svg>

                <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                        <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[10.5px] font-bold ${statusConfig.className}`}>
                            <span className={`h-1.5 w-1.5 rounded-full bg-current ${status === "in_progress" ? "animate-pulse" : ""}`} />
                            {statusConfig.label}
                        </span>

                        {accent && activeUrgency && (
                            <span
                                className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold"
                                style={{
                                    color: accent,
                                    background: `color-mix(in srgb,${accent} 12%,transparent)`,
                                    border: `1px solid color-mix(in srgb,${accent} 30%,transparent)`,
                                }}
                            >
                                <span className="h-1.5 w-1.5 rounded-full" style={{ background: accent }} />
                                {URGENCY_LABEL[activeUrgency]}
                            </span>
                        )}
                    </div>

                    <div className="flex items-center gap-1.5">
                        <button onClick={() => setNotesModalOpen(true)} className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400" title="یادداشت‌ها">
                            <MessageSquareText size={14} />
                        </button>

                        <button type="button" onClick={() => setDeadlineModalOpen(true)} className="flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400" title="مشاهده ددلاین">
                            <CalendarClock size={11} />
                        </button>

                        {!readOnly && (
                            <>
                                <button onClick={openTimeModal} className="flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400" title="تعیین بازه زمانی">
                                    <Clock size={11} />
                                </button>
                                <button onClick={() => onEdit?.(toTask(task))} className="flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400" title="ویرایش تسک">
                                    <Pencil size={11} />
                                </button>
                                <button onClick={() => setShowConfirm(true)} disabled={deleting} className="relative flex h-7 w-7 items-center justify-center rounded-xl bg-red-500/10 text-red-500 disabled:opacity-40" title="حذف تسک">
                                    <BusyContent busy={deleting}>
                                        <Trash2 size={11} />
                                    </BusyContent>
                                </button>
                            </>
                        )}
                    </div>
                </div>

                <div className="flex flex-col gap-1">
                    <h3 className="text-[13.5px] font-extrabold leading-tight" style={{ color: isDark ? "#f3f4f6" : "#1f2937" }}>
                        {task.title}
                    </h3>
                    {task.description && (
                        <p className="line-clamp-2 text-[12px] leading-6" style={{ color: isDark ? "#9ca3af" : "#6b7280" }}>
                            {task.description}
                        </p>
                    )}
                </div>

                <div className="mt-auto flex flex-wrap items-center gap-2 border-t pt-2.5" style={{ borderColor: isDark ? "rgba(255,255,255,.05)" : "rgba(0,0,0,.05)" }}>
                    {employeeIds.length ? employeeIds.map((id) => <EmployeeChip key={id} id={id} isDark={isDark} />) : (
                        <Chip isDark={isDark}><UserRound size={11} />بدون مسئول</Chip>
                    )}
                    {departmentName && <Chip isDark={isDark}><Building2 size={11} />{departmentName}</Chip>}
                    {caseTitle && <Chip isDark={isDark}><FolderKanban size={11} />{caseTitle}</Chip>}
                    {task.files?.length ? <Chip isDark={isDark}><Paperclip size={11} />{task.files.length}</Chip> : null}
                </div>
            </m.div>

            {!readOnly && typeof document !== "undefined" && createPortal(
                <AnimatePresence>
                    {showConfirm && (
                        <m.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="backdrop-blur-layer fixed inset-0 z-[2147483647] flex items-center justify-center bg-gray-950/45 px-4"
                            style={{ }}
                            onClick={closeConfirm}
                        >
                            <m.div
                                initial={{ opacity: 0, scale: 0.96, y: 12 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.96, y: 12 }}
                                transition={{ duration: 0.2 }}
                                onClick={(e) => e.stopPropagation()}
                                dir="rtl"
                                className="w-full max-w-md overflow-hidden rounded-[2rem] border border-gray-100 bg-white shadow-2xl dark:border-white/[0.06] dark:bg-[#111827]"
                            >
                                <div className="flex items-center justify-between px-8 pb-6 pt-8">
                                    <div className="flex items-center gap-2.5">
                                        <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-red-50 dark:bg-red-500/10">
                                            <Trash2 size={15} className="text-red-500" />
                                        </div>
                                        <div>
                                            <h3 className="text-[14px] font-extrabold text-gray-900 dark:text-white">حذف وظیفه</h3>
                                            <p className="mt-0.5 text-[11px] text-gray-400">این عملیات قابل بازگشت نیست</p>
                                        </div>
                                    </div>
                                    <button onClick={closeConfirm} disabled={deleting} className="flex h-8 w-8 items-center justify-center rounded-xl bg-gray-100 text-gray-400 dark:bg-white/[0.05]">
                                        <X size={15} />
                                    </button>
                                </div>

                                <div className="px-8">
                                    <p className="text-[12.5px] font-semibold leading-6 text-gray-500 dark:text-gray-400">
                                        تسک <span className="font-extrabold text-gray-900 dark:text-white">{task.title}</span> برای همیشه حذف خواهد شد.
                                    </p>

                                    {deleteError && (
                                        <div className="mt-4 flex gap-2.5 rounded-2xl bg-red-50 px-3.5 py-3 dark:bg-red-500/10">
                                            <ClipboardX size={14} className="shrink-0 text-red-500" />
                                            <p className="text-[11.5px] font-semibold text-red-500">{deleteError}</p>
                                        </div>
                                    )}
                                </div>

                                <div className="flex gap-2 px-8 pb-8 pt-6">
                                    <button onClick={closeConfirm} disabled={deleting} className="h-11 flex-1 rounded-full bg-gray-100 text-[13px] font-bold text-gray-600 dark:bg-white/[0.05] dark:text-gray-300">
                                        انصراف
                                    </button>
                                    <button onClick={handleDelete} disabled={deleting} className="relative flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-red-600 text-[13px] font-bold text-white">
                                        <BusyContent busy={deleting}>
                                            <><Trash2 size={13} />حذف کن</>
                                        </BusyContent>
                                    </button>
                                </div>
                            </m.div>
                        </m.div>
                    )}
                </AnimatePresence>,
                document.body
            )}

            {!readOnly && (
                <TimeRangeModal
                    open={timeModalOpen}
                    initialStartedAt={stepDeadline?.started_at}
                    initialDeadline={stepDeadline?.deadline}
                    loading={savingTime}
                    error={timeError}
                    onClose={() => setTimeModalOpen(false)}
                    onSubmit={handleTimeSubmit}
                />
            )}

            <TaskDeadlineModal
                open={deadlineModalOpen}
                onClose={() => setDeadlineModalOpen(false)}
                taskId={task.id}
                taskTitle={task.title}
                stepId={stepId}
                onLoaded={setStepDeadline}
            />

            <AdminTaskNotesModal
                isOpen={notesModalOpen}
                onClose={() => setNotesModalOpen(false)}
                taskId={task.id}
                taskTitle={task.title}
            />
        </>
    );
}